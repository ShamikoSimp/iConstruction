"""
URL configuration for iconstructionprj project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from django.conf import settings
from django.conf.urls.static import static
from iconstructionapp import views


urlpatterns = [
	path('admin/', admin.site.urls),
	path('', views.login_view, name='login'),
	path('dashboard/', views.admin_view, name='dashboard'),

	# Rutas del admiinistrador
	path('materials/', views.materials_view, name='materials'),
	path('materials/add/', views.materials_add, name='materials_add'),
	path('materials/edit/<int:mid>/', views.materials_edit, name='materials_edit'),
	path('materials/delete/<int:mid>/', views.materials_delete, name='materials_delete'),
	path('herramientas/', views.herramientas_view, name='herramientas'),
	path('herramientas/add/', views.herramientas_add, name='herramientas_add'),
	path('herramientas/edit/<int:mid>/', views.herramientas_edit, name='herramientas_edit'),
	path('herramientas/delete/<int:mid>/', views.herramientas_delete, name='herramientas_delete'),
	path('bodegas/', views.bodegas_view, name='bodegas'),
	path('bodegas/add/', views.bodegas_add, name='bodegas_add'),
	path('bodegas/edit/<int:mid>/', views.bodegas_edit, name='bodegas_edit'),
	path('bodegas/delete/<int:mid>/', views.bodegas_delete, name='bodegas_delete'),
	path('bodegueros/', views.bodegueros_view, name='bodegueros'),
	path('bodegueros/add/', views.bodegueros_add, name='bodegueros_add'),
	path('bodegueros/edit/<int:mid>/', views.bodegueros_edit, name='bodegueros_edit'),
	path('bodegueros/delete/<int:mid>/', views.bodegueros_delete, name='bodegueros_delete'),
	path('supervisores/', views.supervisores_view, name='supervisores'),
	path('supervisores/add/', views.supervisores_add, name='supervisores_add'),
	path('supervisores/edit/<int:mid>/', views.supervisores_edit, name='supervisores_edit'),
	path('supervisores/delete/<int:mid>/', views.supervisores_delete, name='supervisores_delete'),
	path('obreros/', views.obreros_view, name='obreros'),
	path('obreros/add/', views.obreros_add, name='obreros_add'),
	path('obreros/edit/<int:mid>/', views.obreros_edit, name='obreros_edit'),
	path('obreros/delete/<int:mid>/', views.obreros_delete, name='obreros_delete'),

	# Rutas del supervisor
	path('supervisor/', views.supervisor_dashboard, name='supervisor_dashboard'),
	path('supervisor/actividad/add/', views.actividad_add, name='actividad_add'),
	path('supervisor/actividad/edit/<int:aid>/', views.actividad_edit, name='actividad_edit'),
	path('supervisor/actividad/delete/<int:aid>/', views.actividad_delete, name='actividad_delete'),
	path('supervisor/proyecto/add/', views.proyecto_add, name='proyecto_add'),
	path('supervisor/proyecto/edit/<int:pid>/', views.proyecto_edit, name='proyecto_edit'),
	path('supervisor/proyecto/delete/<int:pid>/', views.proyecto_delete, name='proyecto_delete'),

	# nueva ruta para bodeguero local
	path('bodeguerolo/', views.bodeguero_lo_view, name='bodeguerolo'),
]

if settings.DEBUG:
	urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)

