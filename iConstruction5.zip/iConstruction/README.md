# iConstruction - Manual de Usuario

# Requisitos

1. cd iconstructionprj
2. pip install django
3. pip install mysqlclient
4. pip install pymysql
5. pip install python-dotenv
6. python manage.py seed_data 

# Base de datos

1. Crear en un motor SQL una base de datos llamada constructora_iconstruction
2. Abrir terminal y correr python manage.py migrate
3. Acceder a base de datos ejecutar el contenido de insertinto.txt
4. Abrir terminal y correr python manage.py runserver

## Índice
1. Acceso al Sistema
2. Panel de Administrador
3. Panel de Supervisor
4. Gestión de Materiales
5. Gestión de Herramientas
6. Gestión de Bodegas
7. Gestión de Personal
8. Gestión de Obras

## 1. Acceso al Sistema
- **Usuario Administrador**: 
  - Email: admin@gmail.com
  - Contraseña: adminuno123@

## 2. Panel de Administrador
Acceso a todas las funcionalidades del sistema:
- Gestión de materiales
- Gestión de herramientas
- Gestión de bodegas
- Gestión de bodegueros
- Gestión de supervisores
- Gestión de obreros
- Gestion de marcas y tipos de herramientas y    materiales
- Gestion de regiones

## 4. Gestión de Materiales
Administración de materiales con:
- Nombre
- Precio
- Descripción
- Marca
- Tipo de material

## 5. Gestión de Herramientas
Control de herramientas con:
- Nombre
- Precio
- Dimensiones
- Tipo de herramienta
- Nombre de la marca

## 6. Gestión de Bodegas
Administración de bodegas con:
- Nombre
- Dirección
- Capacidad
- Tipo de bodega

## 7. Gestión de Personal

### 7.1 Bodegueros
Registro de bodegueros con:
- Nombre
- Apellido
- Sueldo
- Bodega asignada

### 7.2 Supervisores
Control de supervisores con:
- Nombre
- Sueldo
- Código de obra asignado

### 7.3 Obreros
Gestión de obreros con:
- Nombre
- Apellido
- Sueldo
- Años de servicio
- Cargo

## Funcionalidades Comunes
Todas las secciones incluyen:
- Búsqueda por texto
- Agregar nuevos registros
- Editar registros existentes
- Eliminar registros (con confirmación)
- Listado en tabla

## 8. Prestamos
Gestion de prestamos:
-Realizar prestamo a un obrero
-Finalizar prestamo marcando el estado en que se devolvio
-Visualizar prestamos realizados

