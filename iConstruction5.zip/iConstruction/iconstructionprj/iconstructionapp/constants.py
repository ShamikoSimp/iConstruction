# Constants for iConstruction
# Fixed/Static options that don't require database

# Estado Devolucion Choices - Return states for tool loans
ESTADO_DEVOLUCION_CHOICES = [
    ('conforme', 'Conforme'),
    ('dañada', 'Dañada'),
    ('perdida', 'Perdida'),
    ('parcial', 'Parcial'),
]

# Estados display mapping with Bootstrap badge colors
ESTADO_DEVOLUCION_COLORS = {
    'conforme': 'success',    # green
    'dañada': 'warning',      # yellow/orange
    'perdida': 'danger',      # red
    'parcial': 'info',        # blue
}

ESTADO_DEVOLUCION_LABELS = {
    'conforme': 'Conforme',
    'dañada': 'Dañada',
    'perdida': 'Perdida',
    'parcial': 'Parcial',
}

# Unidades de medida - Units of measurement (if needed in future)
UNIDADES_MEDIDA_CHOICES = [
    ('kg', 'Kilogramos'),
    ('gr', 'Gramos'),
    ('l', 'Litros'),
    ('ml', 'Mililitros'),
    ('m', 'Metros'),
    ('cm', 'Centímetros'),
    ('un', 'Unidades'),
    ('cajas', 'Cajas'),
]

UNIDADES_MEDIDA_DISPLAY = {
    'kg': 'Kilogramos',
    'gr': 'Gramos',
    'l': 'Litros',
    'ml': 'Mililitros',
    'm': 'Metros',
    'cm': 'Centímetros',
    'un': 'Unidades',
    'cajas': 'Cajas',
}
