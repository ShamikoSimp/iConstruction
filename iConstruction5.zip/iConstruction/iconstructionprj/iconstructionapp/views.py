from django.shortcuts import render, redirect
from django.conf import settings
from django.http import Http404
from django.urls import reverse
from django.contrib.auth.hashers import make_password, check_password
from django.contrib import messages
import os, json, re
from .models import Material, MarcaMaterial, TipoMaterial, Herramienta, MarcaHerramienta, TipoHerramienta, EstadoHerramienta, CategoriaHerramienta, Bodega, TipoBodega, Bodeguero, Trabajador, Obrero, Cargo, RegionBodega, Supervisor, PrestamoHerramienta, HerramientaBodega, MaterialBodega
from django.db import models as dj_models
from django.utils import timezone
from .constants import ESTADO_DEVOLUCION_CHOICES, ESTADO_DEVOLUCION_COLORS, UNIDADES_MEDIDA_CHOICES

# ==================== VISTAS PRINCIPALES ====================
# Las vistas manejan la lógica de negocio y renderean templates
# Cada vista procesa requests HTTP y devuelve respuestas



def admin_view(request):
	# Vista del panel de administración
	return render(request, 'templatesapp/admin.html')

def seed_catalogos(request):
	# Repobla los catálogos (regiones, marcas, tipos, cargos) desde botón en UI
	# Solo accesible por administradores
	if request.method == 'POST':
		if request.session.get('user_type') != 'admin':
			messages.error(request, 'Acceso denegado: solo admin')
			return redirect('dashboard')
		
		try:
			# Regiones
			regiones = [
				'Arica y Parinacota', 'Tarapacá', 'Antofagasta', 'Atacama', 'Coquimbo',
				'Valparaiso', 'Metropolitana', 'O Higgins', 'Maule', 'Biobío',
				'Araucanía', 'Los Ríos', 'Los Lagos', 'Aysén', 'Magallanes'
			]
			for nombre in regiones:
				RegionBodega.objects.get_or_create(nombre_region=nombre)
			
			# Marcas Herramienta
			marcas_herr = ['Bauker', 'Ubermann', 'Makita', 'Stanley']
			for nombre in marcas_herr:
				MarcaHerramienta.objects.get_or_create(nombre_marca=nombre)
			
			# Categorías Herramienta
			categorias = ['Martillo', 'Taladro', 'Escalera']
			for nombre in categorias:
				CategoriaHerramienta.objects.get_or_create(nombre_categoria=nombre)
			
			# Tipos Herramienta
			tipos_herr = ['Electrica', 'Manual']
			for nombre in tipos_herr:
				TipoHerramienta.objects.get_or_create(nombre_tipo_herramienta=nombre)
			
			# Tipos Bodega
			tipos_bodega = ['Local', 'Central']
			for nombre in tipos_bodega:
				TipoBodega.objects.get_or_create(nombre_tipo_bodega=nombre)
			
			# Estados Herramienta
			estados = ['Entregado', 'Faltante']
			for nombre in estados:
				EstadoHerramienta.objects.get_or_create(nombre_estado=nombre)
			
			# Marcas Material
			marcas_mat = ['Makita', 'Pladur', 'Ternium']
			for nombre in marcas_mat:
				MarcaMaterial.objects.get_or_create(nombre_marca=nombre)
			
			# Tipos Material
			tipos_mat = ['Petreo', 'Ceramico', 'Metalico', 'Madera']
			for nombre in tipos_mat:
				TipoMaterial.objects.get_or_create(nombre_tipo_material=nombre)
			
			# Cargos
			cargos = ['Capataz', 'Oficial', 'Ayudante']
			for nombre in cargos:
				Cargo.objects.get_or_create(nombre_cargo=nombre)
			
			messages.success(request, '✅ Todos los catálogos fueron repoblados exitosamente')
		except Exception as e:
			messages.error(request, f'Error al repoblar catálogos: {str(e)}')
		
		return redirect('dashboard')
	
	messages.error(request, 'Método POST requerido')
	return redirect('dashboard')

# ==================== VISTAS CRUD PARA CATÁLOGOS DINÁMICOS ====================

def catalogos_view(request):
	# Muestra todas las listas de catálogos dinámicos (Marcas, Tipos, Cargos, Regiones)
	# Panel principal para que el admin agregue/elimine items de catálogos
	if request.session.get('user_type') != 'admin':
		messages.error(request, 'Acceso denegado: solo admin')
		return redirect('dashboard')
	
	marcas_material = list(MarcaMaterial.objects.all())
	marcas_herramienta = list(MarcaHerramienta.objects.all())
	tipos_material = list(TipoMaterial.objects.all())
	tipos_herramienta = list(TipoHerramienta.objects.all())
	cargos = list(Cargo.objects.all())
	regiones = list(RegionBodega.objects.all())
	
	context = {
		'marcas_material': marcas_material,
		'marcas_herramienta': marcas_herramienta,
		'tipos_material': tipos_material,
		'tipos_herramienta': tipos_herramienta,
		'cargos': cargos,
		'regiones': regiones
	}
	return render(request, 'templatesapp/catalogos.html', context)

# ==================== CRUD MARCAS MATERIAL ====================
def marca_material_add(request):
	# Agrega una nueva marca de material
	if request.session.get('user_type') != 'admin':
		return redirect('dashboard')
	
	if request.method == 'POST':
		nombre = request.POST.get('nombre_marca', '').strip()
		if nombre:
			MarcaMaterial.objects.get_or_create(nombre_marca=nombre)
			messages.success(request, f'Marca de material "{nombre}" agregada')
		else:
			messages.error(request, 'El nombre de la marca es obligatorio')
	return redirect('catalogos')

def marca_material_delete(request, id):
	# Elimina una marca de material por ID
	if request.session.get('user_type') != 'admin':
		return redirect('dashboard')
	
	try:
		marca = MarcaMaterial.objects.get(id_marca=id)
		marca.delete()
		messages.success(request, 'Marca de material eliminada')
	except MarcaMaterial.DoesNotExist:
		messages.error(request, 'Marca no encontrada')
	return redirect('catalogos')

# ==================== CRUD MARCAS HERRAMIENTA ====================
def marca_herramienta_add(request):
	# Agrega una nueva marca de herramienta
	if request.session.get('user_type') != 'admin':
		return redirect('dashboard')
	
	if request.method == 'POST':
		nombre = request.POST.get('nombre_marca', '').strip()
		if nombre:
			MarcaHerramienta.objects.get_or_create(nombre_marca=nombre)
			messages.success(request, f'Marca de herramienta "{nombre}" agregada')
		else:
			messages.error(request, 'El nombre de la marca es obligatorio')
	return redirect('catalogos')

def marca_herramienta_delete(request, id):
	if request.session.get('user_type') != 'admin':
		return redirect('dashboard')
	
	try:
		marca = MarcaHerramienta.objects.get(id_marca=id)
		marca.delete()
		messages.success(request, 'Marca de herramienta eliminada')
	except MarcaHerramienta.DoesNotExist:
		messages.error(request, 'Marca no encontrada')
	return redirect('catalogos')

# ==================== CRUD TIPOS MATERIAL ====================
def tipo_material_add(request):
	# Agrega un nuevo tipo de material
	if request.session.get('user_type') != 'admin':
		return redirect('dashboard')
	
	if request.method == 'POST':
		nombre = request.POST.get('nombre_tipo_material', '').strip()
		if nombre:
			TipoMaterial.objects.get_or_create(nombre_tipo_material=nombre)
			messages.success(request, f'Tipo de material "{nombre}" agregado')
		else:
			messages.error(request, 'El nombre del tipo es obligatorio')
	return redirect('catalogos')

def tipo_material_delete(request, id):
	# Elimina un tipo de material por ID
	if request.session.get('user_type') != 'admin':
		return redirect('dashboard')
	
	try:
		tipo = TipoMaterial.objects.get(id_tipo_material=id)
		tipo.delete()
		messages.success(request, 'Tipo de material eliminado')
	except TipoMaterial.DoesNotExist:
		messages.error(request, 'Tipo no encontrado')
	return redirect('catalogos')

# ==================== CRUD TIPOS HERRAMIENTA ====================
def tipo_herramienta_add(request):
	# Agrega un nuevo tipo de herramienta
	if request.session.get('user_type') != 'admin':
		return redirect('dashboard')
	
	if request.method == 'POST':
		nombre = request.POST.get('nombre_tipo_herramienta', '').strip()
		if nombre:
			TipoHerramienta.objects.get_or_create(nombre_tipo_herramienta=nombre)
			messages.success(request, f'Tipo de herramienta "{nombre}" agregado')
		else:
			messages.error(request, 'El nombre del tipo es obligatorio')
	return redirect('catalogos')

def tipo_herramienta_delete(request, id):
	# Elimina un tipo de herramienta por ID
	if request.session.get('user_type') != 'admin':
		return redirect('dashboard')
	
	try:
		tipo = TipoHerramienta.objects.get(id_tipo_herramienta=id)
		tipo.delete()
		messages.success(request, 'Tipo de herramienta eliminado')
	except TipoHerramienta.DoesNotExist:
		messages.error(request, 'Tipo no encontrado')
	return redirect('catalogos')

# ==================== CRUD CARGOS ====================
def cargo_add(request):
	# Agrega un nuevo cargo
	if request.session.get('user_type') != 'admin':
		return redirect('dashboard')
	
	if request.method == 'POST':
		nombre = request.POST.get('nombre_cargo', '').strip()
		if nombre:
			Cargo.objects.get_or_create(nombre_cargo=nombre)
			messages.success(request, f'Cargo "{nombre}" agregado')
		else:
			messages.error(request, 'El nombre del cargo es obligatorio')
	return redirect('catalogos')

def cargo_delete(request, id):
	if request.session.get('user_type') != 'admin':
		return redirect('dashboard')
	
	try:
		cargo = Cargo.objects.get(id_cargo=id)
		cargo.delete()
		messages.success(request, 'Cargo eliminado')
	except Cargo.DoesNotExist:
		messages.error(request, 'Cargo no encontrado')
	return redirect('catalogos')

# Regiones CRUD
def region_add(request):
	if request.session.get('user_type') != 'admin':
		return redirect('dashboard')
	
	if request.method == 'POST':
		nombre = request.POST.get('nombre_region', '').strip()
		if nombre:
			RegionBodega.objects.get_or_create(nombre_region=nombre)
			messages.success(request, f'Región "{nombre}" agregada')
		else:
			messages.error(request, 'El nombre de la región es obligatorio')
	return redirect('catalogos')

def region_delete(request, id):
	if request.session.get('user_type') != 'admin':
		return redirect('dashboard')
	
	try:
		region = RegionBodega.objects.get(id_region=id)
		region.delete()
		messages.success(request, 'Región eliminada')
	except RegionBodega.DoesNotExist:
		messages.error(request, 'Región no encontrada')
	return redirect('catalogos')

# helpers para convertir instancia a dict para la plantilla
def _material_to_dict(mat):
	return {
		'id': getattr(mat, 'id_material'),
		'name': getattr(mat, 'nombre_material'),
		'price': float(getattr(mat, 'precio') or 0),
		'description': getattr(mat, 'descripcion_material'),
		'brand': getattr(mat.id_marca, 'nombre_marca') if getattr(mat, 'id_marca', None) else '',
		'brand_id': getattr(mat.id_marca, 'id_marca') if getattr(mat, 'id_marca', None) else None,
		'material_type': getattr(mat.id_tipo_material, 'nombre_tipo_material') if getattr(mat, 'id_tipo_material', None) else '',
		'material_type_id': getattr(mat.id_tipo_material, 'id_tipo_material') if getattr(mat, 'id_tipo_material', None) else None,
		'stock_minimo': getattr(mat, 'stock_minimo', None),
		'stock_disponible': getattr(mat, 'stock_disponible', None),
		'dimensiones': getattr(mat, 'dimensiones', ''),
		'expiry_date': getattr(mat, 'fecha_vencimiento', '').isoformat() if getattr(mat, 'fecha_vencimiento', None) else ''
	}

# helper para herramienta
def _herramienta_to_dict(h):
	return {
		'id': getattr(h, 'id_herramienta'),
		'name': getattr(h, 'nombre_herramienta'),
		'estado': getattr(h.id_estado, 'nombre_estado') if getattr(h, 'id_estado', None) else '',
		'estado_id': getattr(h.id_estado, 'id_estado') if getattr(h, 'id_estado', None) else None,
		'categoria': getattr(h.id_categoria, 'nombre_categoria') if getattr(h, 'id_categoria', None) else '',
		'categoria_id': getattr(h.id_categoria, 'id_categoria') if getattr(h, 'id_categoria', None) else None,
		'tool_type': getattr(h.id_tipo_herramienta, 'nombre_tipo_herramienta') if getattr(h, 'id_tipo_herramienta', None) else '',
		'tool_type_id': getattr(h.id_tipo_herramienta, 'id_tipo_herramienta') if getattr(h, 'id_tipo_herramienta', None) else None,
		'brand': getattr(h.id_marca, 'nombre_marca') if getattr(h, 'id_marca', None) else '',
		'brand_id': getattr(h.id_marca, 'id_marca') if getattr(h, 'id_marca', None) else None,
		'price': float(getattr(h, 'precio') or 0),
		'dimensions': getattr(h, 'dimensiones') or '',
		'description': getattr(h, 'descripcion_herramienta'),
		'stock_total': getattr(h, 'stock_total', 0)
	}

# Validación de complejidad de contraseña: mínimo 8 caracteres, al menos un número y un carácter especial
def _password_valid(pw):
	if not pw:
		return False
	# exige al menos un dígito, al menos un carácter no alfanumérico y longitud mínima 8
	return bool(re.match(r'^(?=.*\d)(?=.*[^A-Za-z0-9]).{8,}$', pw))

def materials_view(request):

	q = request.GET.get('q', '').strip()
	edit_id = request.GET.get('edit')
	items_qs = Material.objects.select_related('id_marca', 'id_tipo_material').all()
	if q:
		items_qs = items_qs.filter(
			# búsquedas sobre los campos relevantes
			dj_models.Q(nombre_material__icontains=q) |
			dj_models.Q(descripcion_material__icontains=q) |
			dj_models.Q(id_marca__nombre_marca__icontains=q) |
			dj_models.Q(id_tipo_material__nombre_tipo_material__icontains=q)
		)
	items = [_material_to_dict(m) for m in items_qs]
	edit_item = None
	if edit_id:
		try:
			eid = int(edit_id)
			mat = Material.objects.select_related('id_marca','id_tipo_material').filter(id_material=eid).first()
			if mat:
				edit_item = _material_to_dict(mat)
		except:
			edit_item = None
	# pasar opciones de MarcaMaterial y TipoMaterial para los selects en la plantilla
	marcas = MarcaMaterial.objects.all()
	tipos = TipoMaterial.objects.all()
	return render(request, 'templatesapp/materials.html', {'materials': items, 'q': q, 'edit_item': edit_item, 'brands': marcas, 'types': tipos})

def materials_add(request):

	if request.method == 'POST':
		name = request.POST.get('name', '').strip()
		price = request.POST.get('price', '').strip()
		description = request.POST.get('description', '').strip()
		brand = request.POST.get('brand', '').strip()
		material_type = request.POST.get('material_type', '').strip()

		stock_minimo = request.POST.get('stock_minimo', '').strip()
		stock_disponible = request.POST.get('stock_disponible', '').strip()
		dimensiones = request.POST.get('dimensiones', '').strip()
		fecha_vencimiento = request.POST.get('fecha_vencimiento', '').strip()

		# Guardar datos en sesión por si hay error
		request.session['form_data'] = {
			'name': name,
			'price': price,
			'description': description,
			'brand': brand,
			'material_type': material_type,
			'stock_minimo': stock_minimo,
			'stock_disponible': stock_disponible,
			'dimensiones': dimensiones,
			'fecha_vencimiento': fecha_vencimiento
		}

		# Validaciones basicas
		if not name:
			messages.error(request, 'El nombre del material es obligatorio.')
			return redirect('materials')
		if Material.objects.filter(nombre_material__iexact=name).exists():
			messages.error(request, 'Ya existe un material con ese nombre.')
			return redirect('materials')

		# Validar campos numéricos
		try:
			price_val = float(price) if price != '' else 0
		except Exception:
			messages.error(request, 'Precio inválido. Use un número válido.')
			return redirect('materials')
		try:
			stock_min = int(stock_minimo) if stock_minimo != '' else None
		except Exception:
			messages.error(request, 'Stock mínimo inválido. Use un número entero.')
			return redirect('materials')
		try:
			stock_disp = int(stock_disponible) if stock_disponible != '' else None
		except Exception:
			messages.error(request, 'Stock disponible inválido. Use un número entero.')
			return redirect('materials')

		# obtener marca por id si viene como id, o crear/usar por nombre
		marca_obj = None
		if brand:
			if brand.isdigit():
				marca_obj = MarcaMaterial.objects.filter(id_marca=int(brand)).first()
			if not marca_obj:
				marca_obj, _ = MarcaMaterial.objects.get_or_create(nombre_marca=brand)
		else:
			marca_obj, _ = MarcaMaterial.objects.get_or_create(nombre_marca='Sin marca')

		# obtener tipo por id o por nombre
		tipo_obj = None
		if material_type:
			if material_type.isdigit():
				tipo_obj = TipoMaterial.objects.filter(id_tipo_material=int(material_type)).first()
			if not tipo_obj:
				tipo_obj, _ = TipoMaterial.objects.get_or_create(nombre_tipo_material=material_type)
		else:
			tipo_obj, _ = TipoMaterial.objects.get_or_create(nombre_tipo_material='General')

		Material.objects.create(
			id_marca=marca_obj,
			id_tipo_material=tipo_obj,
			nombre_material=name,
			descripcion_material=description,
			precio=price_val,
			stock_minimo=stock_min,
			stock_disponible=stock_disp if stock_disp is not None else 0,
			dimensiones=dimensiones or '',
			fecha_vencimiento=fecha_vencimiento or None
		)
		# limpiar form_data
		if 'form_data' in request.session:
			del request.session['form_data']
		messages.success(request, 'Material creado correctamente.')
	return redirect('materials')

def materials_edit(request, mid):

	mid = int(mid)
	mat = Material.objects.select_related('id_marca','id_tipo_material').filter(id_material=mid).first()
	if not mat:
		raise Http404("Material no encontrado")
	if request.method == 'POST':
		name = request.POST.get('name', '').strip()
		price = request.POST.get('price', '').strip()
		description = request.POST.get('description', '').strip()
		brand = request.POST.get('brand', '').strip()
		material_type = request.POST.get('material_type', '').strip()

		# Validaciones de nombre
		if not name:
			messages.error(request, 'El nombre del material es obligatorio.')
			return redirect(f"{reverse('materials')}?edit={mid}")
		if Material.objects.filter(nombre_material__iexact=name).exclude(id_material=mid).exists():
			messages.error(request, 'Otro material con ese nombre ya existe.')
			return redirect(f"{reverse('materials')}?edit={mid}")

		# Validar price
		try:
			price_val = float(price) if price != '' else 0
		except Exception:
			messages.error(request, 'Precio inválido. Use un número válido.')
			return redirect(f"{reverse('materials')}?edit={mid}")

		mat.nombre_material = name
		mat.precio = price_val
		mat.descripcion_material = description

		if brand:
			# aceptar id o nombre
			if brand.isdigit():
				marca_obj = MarcaMaterial.objects.filter(id_marca=int(brand)).first()
				if marca_obj:
					mat.id_marca = marca_obj
				else:
					# si el id no existe, crear por nombre
					marca_obj, _ = MarcaMaterial.objects.get_or_create(nombre_marca=brand)
					mat.id_marca = marca_obj
			else:
				marca_obj, _ = MarcaMaterial.objects.get_or_create(nombre_marca=brand)
				mat.id_marca = marca_obj
		if material_type:
			if material_type.isdigit():
				tipo_obj = TipoMaterial.objects.filter(id_tipo_material=int(material_type)).first()
				if tipo_obj:
					mat.id_tipo_material = tipo_obj
				else:
					tipo_obj, _ = TipoMaterial.objects.get_or_create(nombre_tipo_material=material_type)
					mat.id_tipo_material = tipo_obj
			else:
				tipo_obj, _ = TipoMaterial.objects.get_or_create(nombre_tipo_material=material_type)
				mat.id_tipo_material = tipo_obj

		stock_minimo = request.POST.get('stock_minimo', '').strip()
		stock_disponible = request.POST.get('stock_disponible', '').strip()
		dimensiones = request.POST.get('dimensiones', '').strip()
		fecha_vencimiento = request.POST.get('fecha_vencimiento', '').strip()
		try:
			mat.stock_minimo = int(stock_minimo) if stock_minimo != '' else None
		except:
			mat.stock_minimo = None
		try:
			mat.stock_disponible = int(stock_disponible) if stock_disponible != '' else 0
		except:
			mat.stock_disponible = 0
		mat.dimensiones = dimensiones or ''
		mat.fecha_vencimiento = fecha_vencimiento or None

		mat.save()
		messages.success(request, 'Material actualizado correctamente.')
		return redirect('materials')
	# GET -> redirige a la lista con ?edit=mid
	return redirect(f"{reverse('materials')}?edit={mid}")

def materials_delete(request, mid):

	if request.method == 'POST':
		# Evitar borrar si existen referencias en MaterialBodega (integrity constraint)
		try:
			mid_int = int(mid)
		except Exception:
			messages.error(request, 'ID de material inválido.')
			return redirect('materials')

		if MaterialBodega.objects.filter(id_material=mid_int).exists():
			messages.error(request, 'No se puede eliminar el material: existen registros en bodegas que lo referencian. Elimine o reasigne primero las entradas en las bodegas.')
		else:
			Material.objects.filter(id_material=mid_int).delete()
	return redirect('materials')

# Nuevas utilidades y vistas para herramientas (JSON en <BASE_DIR>/data/herramientas.json)
def herramientas_view(request):

	q = request.GET.get('q', '').strip()
	edit_id = request.GET.get('edit')
	items_qs = Herramienta.objects.select_related('id_marca', 'id_tipo_herramienta', 'id_estado', 'id_categoria').all()
	if q:
		items_qs = items_qs.filter(
			dj_models.Q(nombre_herramienta__icontains=q) |
			dj_models.Q(descripcion_herramienta__icontains=q) |
			dj_models.Q(id_marca__nombre_marca__icontains=q) |
			dj_models.Q(id_tipo_herramienta__nombre_tipo_herramienta__icontains=q)
		)
	items = [_herramienta_to_dict(h) for h in items_qs]
	edit_item = None
	if edit_id:
		try:
			eid = int(edit_id)
			h = Herramienta.objects.select_related('id_marca','id_tipo_herramienta','id_estado','id_categoria').filter(id_herramienta=eid).first()
			if h:
				edit_item = _herramienta_to_dict(h)
		except:
			edit_item = None

	# Obtener todas las opciones para los selects
	context = {
		'items': items,
		'q': q,
		'edit_item': edit_item,
		'resource_title': 'Herramientas',
		'list_url': 'herramientas',
		'add_url': 'herramientas_add',
		'edit_url': 'herramientas_edit',
		'delete_url': 'herramientas_delete',
		# Añadir opciones para los selects
		'estados': EstadoHerramienta.objects.all(),
		'categorias': CategoriaHerramienta.objects.all(),
		'tipos': TipoHerramienta.objects.all(),
		'marcas': MarcaHerramienta.objects.all(),
	}
	return render(request, 'templatesapp/resource.html', context)

def herramientas_add(request):

	if request.method == 'POST':
		name = request.POST.get('name', '').strip()
		estado_id = request.POST.get('estado')
		categoria_id = request.POST.get('categoria')
		tipo_id = request.POST.get('tool_type')
		marca_id = request.POST.get('brand')
		price = request.POST.get('price', '').strip()
		stock_total = request.POST.get('stock_total', '').strip()

		# Guardar form_data en sesión por si hay error
		request.session['form_data'] = {
			'name': name,
			'estado': estado_id,
			'categoria': categoria_id,
			'tool_type': tipo_id,
			'brand': marca_id,
			'price': price,
			'stock_total': stock_total,
			'dimensions': request.POST.get('dimensions', ''),
			'description': request.POST.get('description', '')
		}

		# Validaciones
		if not name:
			messages.error(request, 'El nombre de la herramienta es obligatorio.')
			return redirect('herramientas')
		if Herramienta.objects.filter(nombre_herramienta__iexact=name).exists():
			messages.error(request, 'Ya existe una herramienta con ese nombre.')
			return redirect('herramientas')

		# Validar numéricos
		try:
			price_val = float(price) if price != '' else 0
		except Exception:
			messages.error(request, 'Precio inválido. Use un número válido.')
			return redirect('herramientas')
		try:
			stock_val = int(float(stock_total)) if stock_total != '' else 0
		except Exception:
			messages.error(request, 'Stock inválido. Use un número entero.')
			return redirect('herramientas')

		# Obtener los objetos relacionados usando los IDs de los selects
		try:
			estado = EstadoHerramienta.objects.get(id_estado=estado_id)
			categoria = CategoriaHerramienta.objects.get(id_categoria=categoria_id)
			tipo = TipoHerramienta.objects.get(id_tipo_herramienta=tipo_id)
			marca = MarcaHerramienta.objects.get(id_marca=marca_id)
		except (EstadoHerramienta.DoesNotExist, CategoriaHerramienta.DoesNotExist,
				TipoHerramienta.DoesNotExist, MarcaHerramienta.DoesNotExist) as e:
			messages.error(request, 'Selección inválida en alguno de los selects.')
			return redirect('herramientas')

		# Crear la herramienta
		Herramienta.objects.create(
			nombre_herramienta=name,
			id_estado=estado,
			id_categoria=categoria,
			id_tipo_herramienta=tipo,
			id_marca=marca,
			precio=price_val,
			dimensiones=request.POST.get('dimensions', ''),
			descripcion_herramienta=request.POST.get('description', ''),
			stock_total=stock_val
		)
		if 'form_data' in request.session:
			del request.session['form_data']
		messages.success(request, 'Herramienta creada correctamente.')
	return redirect('herramientas')

def herramientas_edit(request, mid):

	mid = int(mid)
	h = Herramienta.objects.select_related('id_marca','id_tipo_herramienta','id_estado','id_categoria').filter(id_herramienta=mid).first()
	if not h:
		raise Http404("Herramienta no encontrada")
	if request.method == 'POST':
		name = request.POST.get('name', '').strip()
		estado_id = request.POST.get('estado')
		categoria_id = request.POST.get('categoria')
		tipo_id = request.POST.get('tool_type')
		marca_id = request.POST.get('brand')
		price = request.POST.get('price', '').strip()
		stock_total = request.POST.get('stock_total', '').strip()

		# Validaciones
		if not name:
			messages.error(request, 'El nombre de la herramienta es obligatorio.')
			return redirect(f"{reverse('herramientas')}?edit={mid}")
		if Herramienta.objects.filter(nombre_herramienta__iexact=name).exclude(id_herramienta=mid).exists():
			messages.error(request, 'Otro registro con ese nombre ya existe.')
			return redirect(f"{reverse('herramientas')}?edit={mid}")

		try:
			price_val = float(price) if price != '' else 0
		except Exception:
			messages.error(request, 'Precio inválido. Use un número válido.')
			return redirect(f"{reverse('herramientas')}?edit={mid}")
		try:
			stock_val = int(float(stock_total)) if stock_total != '' else 0
		except Exception:
			messages.error(request, 'Stock inválido. Use un número entero.')
			return redirect(f"{reverse('herramientas')}?edit={mid}")

		# Obtener relaciones
		try:
			h.id_estado = EstadoHerramienta.objects.get(id_estado=estado_id)
			h.id_categoria = CategoriaHerramienta.objects.get(id_categoria=categoria_id)
			h.id_tipo_herramienta = TipoHerramienta.objects.get(id_tipo_herramienta=tipo_id)
			h.id_marca = MarcaHerramienta.objects.get(id_marca=marca_id)
		except (EstadoHerramienta.DoesNotExist, CategoriaHerramienta.DoesNotExist,
				TipoHerramienta.DoesNotExist, MarcaHerramienta.DoesNotExist) as e:
			messages.error(request, 'Selección inválida en alguno de los selects.')
			return redirect(f"{reverse('herramientas')}?edit={mid}")

		# Actualizar campos simples
		h.nombre_herramienta = name
		h.precio = price_val
		h.dimensiones = request.POST.get('dimensions', '')
		h.descripcion_herramienta = request.POST.get('description', '')
		h.stock_total = stock_val

		h.save()
		messages.success(request, 'Herramienta actualizada correctamente.')
		return redirect('herramientas')
	return redirect(f"{reverse('herramientas')}?edit={mid}")

def herramientas_delete(request, mid):

	if request.method == 'POST':
		# Evitar borrar si existen referencias en HerramientaBodega (integrity constraint)
		try:
			mid_int = int(mid)
		except Exception:
			messages.error(request, 'ID de herramienta inválido.')
			return redirect('herramientas')

		if HerramientaBodega.objects.filter(id_herramienta=mid_int).exists():
			messages.error(request, 'No se puede eliminar la herramienta: existen registros en bodegas que la referencian. Elimine o reasigne primero las entradas en las bodegas.')
		else:
			Herramienta.objects.filter(id_herramienta=mid_int).delete()
	return redirect('herramientas')

def _bodega_file_path():
	data_dir = os.path.join(settings.BASE_DIR, 'data')
	os.makedirs(data_dir, exist_ok=True)
	return os.path.join(data_dir, 'bodegas.json')

def _load_bodegas():
	fn = _bodega_file_path()
	if not os.path.exists(fn):
		with open(fn, 'w', encoding='utf-8') as f:
			json.dump([], f, ensure_ascii=False, indent=2)
	with open(fn, 'r', encoding='utf-8') as f:
		try:
			return json.load(f)
		except json.JSONDecodeError:
			return []

def _save_bodegas(items):
	fn = _bodega_file_path()
	with open(fn, 'w', encoding='utf-8') as f:
		json.dump(items, f, ensure_ascii=False, indent=2)

def _bodega_to_dict(b):
	return {
		'id': getattr(b, 'id_bodega'),
		'name': getattr(b, 'nombre_bodega'),
		'address': getattr(b, 'direccion'),
		'capacity': getattr(b, 'capacidad'),
		'warehouse_type': getattr(b.id_tipo_bodega, 'nombre_tipo_bodega') if getattr(b, 'id_tipo_bodega', None) else '',
		'warehouse_type_id': getattr(b.id_tipo_bodega, 'id_tipo_bodega') if getattr(b, 'id_tipo_bodega', None) else '',
		'region': getattr(b.id_region, 'nombre_region') if getattr(b, 'id_region', None) else '',
		'region_id': getattr(b.id_region, 'id_region') if getattr(b, 'id_region', None) else ''
	}

def bodegas_view(request):
	q = request.GET.get('q', '').strip()
	edit_id = request.GET.get('edit')
	items_qs = Bodega.objects.select_related('id_tipo_bodega', 'id_region').all()
	if q:
		items_qs = items_qs.filter(
			dj_models.Q(nombre_bodega__icontains=q) |
			dj_models.Q(direccion__icontains=q) |
			dj_models.Q(id_tipo_bodega__nombre_tipo_bodega__icontains=q)
		)
	items = [_bodega_to_dict(b) for b in items_qs]
	edit_item = None

	
	if edit_id:
		try:
			eid = int(edit_id)
			b = Bodega.objects.select_related('id_tipo_bodega', 'id_region').filter(id_bodega=eid).first()
			if b:
				edit_item = _bodega_to_dict(b)
		except:
			edit_item = None
	# opciones para select de tipo de bodega
	tipo_bodegas = TipoBodega.objects.all()
	regiones = RegionBodega.objects.all()  # Agregamos las regiones
	context = {
		'items': items,
		'q': q,
		'edit_item': edit_item,
		'tipo_bodegas': tipo_bodegas,
		'regiones': regiones  # Agregamos las regiones al contexto
	}
	return render(request, 'templatesapp/bodegas.html', context)

def regiones_view(request):

	q = request.GET.get('q', '').strip()
	edit_id = request.GET.get('edit')
	items_qs = Bodega.objects.select_related('id_region').all()
	if q:
		items_qs = items_qs.filter(
			dj_models.Q(nombre_region__icontains=q) 
		)
	items = [_bodega_to_dict(b) for b in items_qs]
	edit_item = None

	
	if edit_id:
		try:
			eid = int(edit_id)
			b = Bodega.objects.select_related('id_region').filter(id_bodega=eid).first()
			if b:
				edit_item = _bodega_to_dict(b)
		except:
			edit_item = None
	# opciones para select de tipo de bodega
	regiones = RegionBodega.objects.all()
	context = {
		'items': items,
		'q': q,
		'edit_item': edit_item,
		'regiones': regiones,
	}
	return render(request, 'templatesapp/bodegas.html', context)

def bodegas_add(request):

	if request.method == 'POST':
		name = request.POST.get('name', '').strip()
		address = request.POST.get('address', '').strip()
		capacity = request.POST.get('capacity', '').strip()
		warehouse_type_id = request.POST.get('warehouse_type', '').strip()
		region_id = request.POST.get('region', '').strip()

		# Guardar en sesión en caso de error
		request.session['form_data'] = {
			'name': name,
			'address': address,
			'capacity': capacity,
			'warehouse_type': warehouse_type_id,
			'region': region_id
		}

		# Validaciones
		if not name:
			messages.error(request, 'El nombre de la bodega es obligatorio.')
			return redirect('bodegas')
		if Bodega.objects.filter(nombre_bodega__iexact=name).exists():
			messages.error(request, 'Ya existe una bodega con ese nombre.')
			return redirect('bodegas')

		try:
			cap_val = float(capacity) if capacity != '' else 0
		except Exception:
			messages.error(request, 'Capacidad inválida. Use un número válido.')
			return redirect('bodegas')

		tipo_obj = None
		region_obj = None
		if warehouse_type_id:
			try:
				tipo_obj = TipoBodega.objects.get(id_tipo_bodega=int(warehouse_type_id))
			except TipoBodega.DoesNotExist:
				tipo_obj = None
		if region_id:
			try:
				region_obj = RegionBodega.objects.get(id_region=int(region_id))
			except RegionBodega.DoesNotExist:
				region_obj = None

		Bodega.objects.create(
			id_tipo_bodega=tipo_obj,
			id_region=region_obj,
			nombre_bodega=name or None,
			capacidad=cap_val,
			direccion=address or ''
		)
		if 'form_data' in request.session:
			del request.session['form_data']
		messages.success(request, 'Bodega creada correctamente.')
	return redirect('bodegas')

def bodegas_edit(request, mid):

	mid = int(mid)
	b = Bodega.objects.select_related('id_tipo_bodega').filter(id_bodega=mid).first()
	if not b:
		raise Http404("Bodega no encontrada")
	if request.method == 'POST':
		name = request.POST.get('name', '').strip()
		address = request.POST.get('address', '').strip()
		capacity = request.POST.get('capacity', '').strip()
		warehouse_type_id = request.POST.get('warehouse_type', '').strip()
		region_id = request.POST.get('region', '').strip()

		# Validaciones
		if not name:
			messages.error(request, 'El nombre de la bodega es obligatorio.')
			return redirect(f"{reverse('bodegas')}?edit={mid}")
		if Bodega.objects.filter(nombre_bodega__iexact=name).exclude(id_bodega=mid).exists():
			messages.error(request, 'Otro registro con ese nombre de bodega ya existe.')
			return redirect(f"{reverse('bodegas')}?edit={mid}")

		try:
			cap_val = float(capacity) if capacity != '' else 0
		except Exception:
			messages.error(request, 'Capacidad inválida. Use un número válido.')
			return redirect(f"{reverse('bodegas')}?edit={mid}")

		b.nombre_bodega = name or None
		b.direccion = address
		b.capacidad = cap_val
		if warehouse_type_id:
			try:
				b.id_tipo_bodega = TipoBodega.objects.get(id_tipo_bodega=int(warehouse_type_id))
			except TipoBodega.DoesNotExist:
				b.id_tipo_bodega = None
		else:
			b.id_tipo_bodega = None
		if region_id:
			try:
				b.id_region = RegionBodega.objects.get(id_region=int(region_id))
			except RegionBodega.DoesNotExist:
				b.id_region = None
		else:
			b.id_region = None
		b.save()
		messages.success(request, 'Bodega actualizada correctamente.')
		return redirect('bodegas')
	# GET -> redirige a la página de lista con ?edit=mid
	return redirect(f"{reverse('bodegas')}?edit={mid}")

def bodegas_delete(request, mid):

	if request.method == 'POST':
		# Evitar borrar si existen referencias en tablas dependientes (herramientas/materiales/bodegueros)
		try:
			mid_int = int(mid)
		except Exception:
			messages.error(request, 'ID de bodega inválido.')
			return redirect('bodegas')

		refs = []
		if HerramientaBodega.objects.filter(id_bodega=mid_int).exists():
			refs.append('herramientas asignadas')
		if MaterialBodega.objects.filter(id_bodega=mid_int).exists():
			refs.append('materiales asignados')
		if Bodeguero.objects.filter(id_bodega=mid_int).exists():
			refs.append('bodegueros asignados')

		if refs:
			messages.error(request, 'No se puede eliminar la bodega: existen referencias en la base de datos (' + ', '.join(refs) + '). Elimine o reasigne primero esas entradas.')
		else:
			Bodega.objects.filter(id_bodega=mid_int).delete()
	return redirect('bodegas')

def _bodeguero_file_path():
	data_dir = os.path.join(settings.BASE_DIR, 'data')
	os.makedirs(data_dir, exist_ok=True)
	return os.path.join(data_dir, 'bodegueros.json')

def _load_bodegueros():
	fn = _bodeguero_file_path()
	if not os.path.exists(fn):
		with open(fn, 'w', encoding='utf-8') as f:
			json.dump([], f, ensure_ascii=False, indent=2)
	with open(fn, 'r', encoding='utf-8') as f:
		try:
			return json.load(f)
		except json.JSONDecodeError:
			return []

def _save_bodegueros(items):
	fn = _bodeguero_file_path()
	with open(fn, 'w', encoding='utf-8') as f:
		json.dump(items, f, ensure_ascii=False, indent=2)

def _bodeguero_to_dict(b):
	return {
		'id': getattr(b, 'id_bodeguero'),
		'nombre': getattr(b.id_trabajador, 'nombre') if getattr(b, 'id_trabajador', None) else '',
		'rut': getattr(b.id_trabajador, 'rut') if getattr(b, 'id_trabajador', None) else '',
		'email': getattr(b.id_trabajador, 'email') if getattr(b, 'id_trabajador', None) else '',
		'telefono': getattr(b.id_trabajador, 'telefono') if getattr(b, 'id_trabajador', None) else '',
		'sueldo': getattr(b.id_trabajador, 'sueldo') if getattr(b, 'id_trabajador', None) else '',
		'fecha_contratacion': getattr(b.id_trabajador, 'fecha_contratacion').isoformat() if getattr(b, 'id_trabajador', None) and getattr(b.id_trabajador, 'fecha_contratacion', None) else '',
		'bodega': getattr(b.id_bodega, 'nombre_bodega') if getattr(b, 'id_bodega', None) else '',
		'bodega_id': getattr(b.id_bodega, 'id_bodega') if getattr(b, 'id_bodega', None) else '',
		'contrasena': '',  # No mostrar el hash, dejar vacío
		'es_central': getattr(b, 'es_central', False)
	}

def bodegueros_view(request):

	q = request.GET.get('q', '').strip()
	edit_id = request.GET.get('edit')
	items_qs = Bodeguero.objects.select_related('id_trabajador', 'id_bodega').all()
	if q:
		items_qs = items_qs.filter(
			# corregido: usar el campo 'nombre' del Trabajador
			dj_models.Q(id_trabajador__nombre__icontains=q) |
			dj_models.Q(id_trabajador__rut__icontains=q) |
			dj_models.Q(id_bodega__nombre_bodega__icontains=q)
		)
	items = [_bodeguero_to_dict(b) for b in items_qs]
	edit_item = None
	if edit_id:
		try:
			eid = int(edit_id)
			b = Bodeguero.objects.select_related('id_trabajador','id_bodega').filter(id_bodeguero=eid).first()
			if b:
				edit_item = _bodeguero_to_dict(b)
		except:
			edit_item = None
	# pasar bodegas para el select en el formulario
	bodegas = Bodega.objects.all()
	
	# Recuperar datos del formulario de la sesión si hay errores
	form_data = request.session.pop('form_data', {})
	
	context = {
		'items': items,
		'q': q,
		'edit_item': edit_item,
		'bodegas': bodegas,
		'form_data': form_data
	}
	return render(request, 'templatesapp/bodegueros.html', context)

def bodegueros_add(request):

	if request.method == 'POST':
		nombre = request.POST.get('nombre_completo', '').strip() or request.POST.get('nombre', '').strip() or request.POST.get('first_name', '').strip()
		rut = request.POST.get('rut', '').strip()
		email = request.POST.get('email', '').strip()
		telefono = request.POST.get('telefono', '').strip()
		sueldo = request.POST.get('sueldo', '').strip()
		fecha_contratacion = request.POST.get('fecha_contratacion', '').strip()
		bodega_id = request.POST.get('bodega', '').strip()
		contrasena = request.POST.get('contrasena', '').strip()

		# Validación de fecha de contratación (OBLIGATORIA)
		if not fecha_contratacion:
			request.session['form_data'] = {
				'nombre_completo': nombre,
				'rut': rut,
				'email': email,
				'telefono': telefono,
				'sueldo': sueldo,
				'fecha_contratacion': fecha_contratacion,
				'bodega': bodega_id
			}
			messages.error(request, "⚠️ La fecha de contratación es obligatoria. Por favor, ingresa una fecha válida.")
			return redirect('bodegueros')

		# Validación de contraseña (OBLIGATORIA)
		if not contrasena:
			request.session['form_data'] = {
				'nombre_completo': nombre,
				'rut': rut,
				'email': email,
				'telefono': telefono,
				'sueldo': sueldo,
				'fecha_contratacion': fecha_contratacion,
				'bodega': bodega_id
			}
			messages.error(request, "🔒 La contraseña es obligatoria. Por favor, ingresa una contraseña.")
			return redirect('bodegueros')

		# Validación de complejidad de contraseña
		if not _password_valid(contrasena):
			request.session['form_data'] = {
				'nombre_completo': nombre,
				'rut': rut,
				'email': email,
				'telefono': telefono,
				'sueldo': sueldo,
				'fecha_contratacion': fecha_contratacion,
				'bodega': bodega_id
			}
			messages.error(request, "🔒 La contraseña debe tener al menos 8 caracteres, incluir al menos un número y un carácter especial.")
			return redirect('bodegueros')

		# Validaciones de formato
		name_ok = bool(re.match(r'^[A-Za-zÁÉÍÓÚáéíóúÑñ ]+$', nombre)) if nombre else False
		digits_rut = rut.isdigit() if rut else True
		digits_telefono = telefono.isdigit() if telefono else True
		digits_sueldo = sueldo.isdigit() if sueldo else True

		# Si hay error, guardar datos en sesión y redirigir
		if not name_ok or not digits_rut or not digits_telefono or not digits_sueldo:
			# guardar en sesión para recuperar después
			request.session['form_data'] = {
				'nombre_completo': nombre,
				'rut': rut,
				'email': email,
				'telefono': telefono,
				'sueldo': sueldo,
				'fecha_contratacion': fecha_contratacion,
				'bodega': bodega_id
			}
			messages.error(request, "Validación de formato fallida. Por favor corrige los datos.")
			return redirect('bodegueros')
		
		if email and Trabajador.objects.filter(email=email).exists():
			request.session['form_data'] = {
				'nombre_completo': nombre,
				'rut': rut,
				'email': email,
				'telefono': telefono,
				'sueldo': sueldo,
				'fecha_contratacion': fecha_contratacion,
				'bodega': bodega_id
			}
			messages.error(request, "El email ya está registrado.")
			return redirect('bodegueros')
		if nombre and Trabajador.objects.filter(nombre=nombre).exists():
			request.session['form_data'] = {
				'nombre_completo': nombre,
				'rut': rut,
				'email': email,
				'telefono': telefono,
				'sueldo': sueldo,
				'fecha_contratacion': fecha_contratacion,
				'bodega': bodega_id
			}
			messages.error(request, "El nombre completo ya está registrado.")
			return redirect('bodegueros')
		if rut and Trabajador.objects.filter(rut=rut).exists():
			request.session['form_data'] = {
				'nombre_completo': nombre,
				'rut': rut,
				'email': email,
				'telefono': telefono,
				'sueldo': sueldo,
				'fecha_contratacion': fecha_contratacion,
				'bodega': bodega_id
			}
			messages.error(request, "El RUT ya está registrado.")
			return redirect('bodegueros')
		if telefono and Trabajador.objects.filter(telefono=telefono).exists():
			request.session['form_data'] = {
				'nombre_completo': nombre,
				'rut': rut,
				'email': email,
				'telefono': telefono,
				'sueldo': sueldo,
				'fecha_contratacion': fecha_contratacion,
				'bodega': bodega_id
			}
			messages.error(request, "El teléfono ya está registrado.")
			return redirect('bodegueros')

		# Si pasó todas las validaciones, crear el bodeguero
		try:
			sueldo_val = float(sueldo) if sueldo != '' else None
		except:
			sueldo_val = None

		# Hashear contraseña si se proporciona
		contrasena_hasheada = make_password(contrasena) if contrasena else None

		# crear Trabajador
		trab = Trabajador.objects.create(
			nombre=nombre or '',
			rut=rut or '',
			email=email or None,
			telefono=telefono or '',
			sueldo=int(sueldo_val) if sueldo_val is not None else None,
			fecha_contratacion=fecha_contratacion or None,
			contrasena=contrasena_hasheada
		)
		# asociar Bodega si existe
		bodega_obj = None
		if bodega_id:
			try:
				bodega_obj = Bodega.objects.get(id_bodega=int(bodega_id))
			except Bodega.DoesNotExist:
				bodega_obj = None
		# crear Bodeguero
		# determinar si es bodeguero central (campo opcional en formulario)
		es_central_flag = request.POST.get('es_central')
		is_central = True if str(es_central_flag).lower() in ['1', 'true', 'on', 'yes'] else False
		Bodeguero.objects.create(
			id_trabajador=trab,
			id_bodega=bodega_obj,
			es_central=is_central
		)
		messages.success(request, "Bodeguero creado correctamente.")
	
	return redirect('bodegueros')

def bodegueros_edit(request, mid):

	mid = int(mid)
	b = Bodeguero.objects.select_related('id_trabajador','id_bodega').filter(id_bodeguero=mid).first()
	if not b:
		raise Http404("Bodeguero no encontrado")
	if request.method == 'POST':
		# aceptar varios nombres de campo por compatibilidad
		nombre = request.POST.get('nombre_completo', '').strip() or request.POST.get('nombre', '').strip() or request.POST.get('first_name', '').strip()
		rut = request.POST.get('rut', '').strip()
		email = request.POST.get('email', '').strip()
		telefono = request.POST.get('telefono', '').strip()
		sueldo = request.POST.get('sueldo', '').strip()
		fecha_contratacion = request.POST.get('fecha_contratacion', '').strip()
		contrasena = request.POST.get('contrasena', '').strip()

		# Validación de fecha de contratación (OBLIGATORIA)
		if fecha_contratacion == '' and not b.id_trabajador.fecha_contratacion:
			messages.error(request, "⚠️ La fecha de contratación es obligatoria. Por favor, ingresa una fecha válida.")
			return redirect(f"{reverse('bodegueros')}?edit={mid}")

		# Validaciones de formato
		if nombre and not re.match(r'^[A-Za-zÁÉÍÓÚáéíóúÑñ ]+$', nombre):
			messages.error(request, "El nombre completo sólo puede contener letras y espacios.")
			return redirect(f"{reverse('bodegueros')}?edit={mid}")
		if rut and not rut.isdigit():
			messages.error(request, "RUT sólo debe contener números.")
			return redirect(f"{reverse('bodegueros')}?edit={mid}")
		if telefono and not telefono.isdigit():
			messages.error(request, "Teléfono sólo debe contener números.")
			return redirect(f"{reverse('bodegueros')}?edit={mid}")
		if sueldo and not sueldo.isdigit():
			messages.error(request, "Sueldo sólo debe contener números.")
			return redirect(f"{reverse('bodegueros')}?edit={mid}")

		# Unicidad: excluir el propio registro al editar
		trab = b.id_trabajador
		if email and Trabajador.objects.filter(email=email).exclude(id_trabajador=trab.id_trabajador).exists():
			messages.error(request, "El email ya está registrado por otro trabajador.")
			return redirect(f"{reverse('bodegueros')}?edit={mid}")
		if nombre and Trabajador.objects.filter(nombre=nombre).exclude(id_trabajador=trab.id_trabajador).exists():
			messages.error(request, "El nombre completo ya está registrado por otro trabajador.")
			return redirect(f"{reverse('bodegueros')}?edit={mid}")
		if rut and Trabajador.objects.filter(rut=rut).exclude(id_trabajador=trab.id_trabajador).exists():
			messages.error(request, "El RUT ya está registrado por otro trabajador.")
			return redirect(f"{reverse('bodegueros')}?edit={mid}")
		if telefono and Trabajador.objects.filter(telefono=telefono).exclude(id_trabajador=trab.id_trabajador).exists():
			messages.error(request, "El teléfono ya está registrado por otro trabajador.")
			return redirect(f"{reverse('bodegueros')}?edit={mid}")

		# actualizar trabajador
		trab.nombre = nombre or trab.nombre
		trab.rut = rut or trab.rut
		trab.email = email or trab.email
		trab.telefono = telefono or trab.telefono
		try:
			trab.sueldo = int(sueldo) if sueldo != '' else trab.sueldo
		except:
			trab.sueldo = trab.sueldo
		trab.fecha_contratacion = fecha_contratacion or trab.fecha_contratacion
		
		# Actualizar contraseña con hash si se proporciona
		if contrasena:
			# validar complejidad antes de aceptar
			if not _password_valid(contrasena):
				messages.error(request, "🔒 La contraseña debe tener al menos 8 caracteres, incluir al menos un número y un carácter especial.")
				return redirect(f"{reverse('bodegueros')}?edit={mid}")
			trab.contrasena = make_password(contrasena)
		trab.save()

		# actualizar bodega asignada
		bodega_id = request.POST.get('bodega', '').strip()
		if bodega_id:
			try:
				b.id_bodega = Bodega.objects.get(id_bodega=int(bodega_id))
			except Bodega.DoesNotExist:
				b.id_bodega = None
		else:
			b.id_bodega = None
		b.save()

		# actualizar flag es_central si se recibe
		es_central_flag = request.POST.get('es_central')
		if es_central_flag is not None:
			b.es_central = True if str(es_central_flag).lower() in ['1', 'true', 'on', 'yes'] else False
			b.save()
		messages.success(request, "Bodeguero actualizado correctamente.")
		return redirect('bodegueros')
	# GET -> redirige a la lista de bodegueros with ?edit=mid
	return redirect(f"{reverse('bodegueros')}?edit={mid}")

def bodegueros_delete(request, mid):

	if request.method == 'POST':
		b = Bodeguero.objects.filter(id_bodeguero=int(mid)).first()
		if b:
			# opcional: eliminar también trabajador relacionado
			trab = b.id_trabajador
			b.delete()
			# eliminar trabajador si no usado en otras tablas (riesgo: chequear dependencias)
			try:
				trab.delete()
			except:
				pass
	return redirect('bodegueros')

def _supervisor_file_path():
	data_dir = os.path.join(settings.BASE_DIR, 'data')
	os.makedirs(data_dir, exist_ok=True)
	return os.path.join(data_dir, 'supervisores.json')

def _load_supervisores():
	fn = _supervisor_file_path()
	if not os.path.exists(fn):
		with open(fn, 'w', encoding='utf-8') as f:
			json.dump([], f, ensure_ascii=False, indent=2)
	with open(fn, 'r', encoding='utf-8') as f:
		try:
			return json.load(f)
		except json.JSONDecodeError:
			return []

def _save_supervisores(items):
	fn = _supervisor_file_path()
	with open(fn, 'w', encoding='utf-8') as f:
		json.dump(items, f, ensure_ascii=False, indent=2)

def supervisores_view(request):

	q = request.GET.get('q', '').strip()
	edit_id = request.GET.get('edit')
	form_data = request.session.pop('form_data', {})
	
	items = _load_supervisores()
	if q:
		q_lower = q.lower()
		items = [
			m for m in items if
			q_lower in str(m.get('nombre','')).lower() or
			q_lower in str(m.get('rut','')).lower() or
			q_lower in str(m.get('email','')).lower()
		]
	edit_item = None
	if edit_id:
		try:
			eid = int(edit_id)
			edit_item = next((m for m in _load_supervisores() if m.get('id') == eid), None)
		except:
			edit_item = None
	context = {
		'items': items,
		'q': q,
		'edit_item': edit_item,
		'form_data': form_data
	}
	return render(request, 'templatesapp/supervisores.html', context)

def supervisores_add(request):

	if request.method == 'POST':
		nombre = request.POST.get('nombre_completo', '').strip()
		rut = request.POST.get('rut', '').strip()
		email = request.POST.get('email', '').strip()
		telefono = request.POST.get('telefono', '').strip()
		sueldo = request.POST.get('sueldo', '').strip()
		fecha_contratacion = request.POST.get('fecha_contratacion', '').strip()
		contrasena = request.POST.get('contrasena', '').strip()

		# Validación de fecha de contratación (OBLIGATORIA)
		if not fecha_contratacion:
			request.session['form_data'] = {
				'nombre_completo': nombre,
				'rut': rut,
				'email': email,
				'telefono': telefono,
				'sueldo': sueldo,
				'fecha_contratacion': fecha_contratacion,
				'contrasena': contrasena
			}
			messages.error(request, "⚠️ La fecha de contratación es obligatoria. Por favor, ingresa una fecha válida.")
			return redirect('supervisores')

		# Validación de contraseña (OBLIGATORIA)
		if not contrasena:
			request.session['form_data'] = {
				'nombre_completo': nombre,
				'rut': rut,
				'email': email,
				'telefono': telefono,
				'sueldo': sueldo,
				'fecha_contratacion': fecha_contratacion,
				'contrasena': contrasena
			}
			messages.error(request, "🔒 La contraseña es obligatoria. Por favor, ingresa una contraseña.")
			return redirect('supervisores')

		# Validación de complejidad de contraseña
		if not _password_valid(contrasena):
			request.session['form_data'] = {
				'nombre_completo': nombre,
				'rut': rut,
				'email': email,
				'telefono': telefono,
				'sueldo': sueldo,
				'fecha_contratacion': fecha_contratacion,
				'contrasena': contrasena
			}
			messages.error(request, "🔒 La contraseña debe tener al menos 8 caracteres, incluir al menos un número y un carácter especial.")
			return redirect('supervisores')

		# Validaciones de formato
		name_ok = bool(re.match(r'^[A-Za-zÁÉÍÓÚáéíóúÑñ ]+$', nombre)) if nombre else False
		digits_rut = rut.isdigit() if rut else True
		digits_telefono = telefono.isdigit() if telefono else True
		digits_sueldo = sueldo.isdigit() if sueldo else True

		# Si hay error, guardar datos en sesión y redirigir
		if not name_ok or not digits_rut or not digits_telefono or not digits_sueldo:
			request.session['form_data'] = {
				'nombre_completo': nombre,
				'rut': rut,
				'email': email,
				'telefono': telefono,
				'sueldo': sueldo,
				'fecha_contratacion': fecha_contratacion,
				'contrasena': contrasena
			}
			messages.error(request, "Validación de formato fallida. Por favor corrige los datos.")
			return redirect('supervisores')

		# Verificar unicidad
		items = _load_supervisores()
		if any(s.get('rut') == rut for s in items):
			messages.error(request, "El RUT ya está registrado.")
			return redirect('supervisores')
		if email and any(s.get('email') == email for s in items):
			messages.error(request, "El email ya está registrado.")
			return redirect('supervisores')

		# Procesar datos
		try:
			sueldo_val = int(float(sueldo)) if sueldo != '' else 0
		except:
			sueldo_val = 0

		contrasena_hasheada = make_password(contrasena) if contrasena else None

		# Crear supervisor
		next_id = max([m.get('id', 0) for m in items], default=0) + 1
		items.append({
			'id': next_id,
			'nombre': nombre or '',
			'rut': rut or '',
			'email': email or None,
			'telefono': telefono or '',
			'sueldo': sueldo_val,
			'fecha_contratacion': fecha_contratacion or None,
			'contrasena': contrasena_hasheada
		})
		_save_supervisores(items)
		messages.success(request, "Supervisor creado correctamente.")
	
	return redirect('supervisores')

def supervisores_edit(request, mid):

	mid = int(mid)
	items = _load_supervisores()
	item = next((m for m in items if m.get('id') == mid), None)
	if not item:
		raise Http404("Supervisor no encontrado")
	if request.method == 'POST':
		nombre = request.POST.get('nombre_completo', '').strip()
		rut = request.POST.get('rut', '').strip()
		email = request.POST.get('email', '').strip()
		telefono = request.POST.get('telefono', '').strip()
		sueldo = request.POST.get('sueldo', '').strip()
		fecha_contratacion = request.POST.get('fecha_contratacion', '').strip()
		contrasena = request.POST.get('contrasena', '').strip()

		# Validación de fecha de contratación
		if fecha_contratacion == '' and not item.get('fecha_contratacion'):
			messages.error(request, "⚠️ La fecha de contratación es obligatoria. Por favor, ingresa una fecha válida.")
			return redirect(f"{reverse('supervisores')}?edit={mid}")

		# Validaciones de formato
		if nombre and not re.match(r'^[A-Za-zÁÉÍÓÚáéíóúÑñ ]+$', nombre):
			messages.error(request, "El nombre completo sólo puede contener letras y espacios.")
			return redirect(f"{reverse('supervisores')}?edit={mid}")
		if rut and not rut.isdigit():
			messages.error(request, "RUT sólo debe contener números.")
			return redirect(f"{reverse('supervisores')}?edit={mid}")
		if telefono and not telefono.isdigit():
			messages.error(request, "Teléfono sólo debe contener números.")
			return redirect(f"{reverse('supervisores')}?edit={mid}")
		if sueldo and not sueldo.isdigit():
			messages.error(request, "Sueldo sólo debe contener números.")
			return redirect(f"{reverse('supervisores')}?edit={mid}")

		# Verificar unicidad (excluyendo el registro actual)
		other_items = [s for s in items if s.get('id') != mid]
		if rut and any(s.get('rut') == rut for s in other_items):
			messages.error(request, "El RUT ya está registrado por otro supervisor.")
			return redirect(f"{reverse('supervisores')}?edit={mid}")
		if email and any(s.get('email') == email for s in other_items):
			messages.error(request, "El email ya está registrado por otro supervisor.")
			return redirect(f"{reverse('supervisores')}?edit={mid}")

		# Actualizar supervisor
		item['nombre'] = nombre or item.get('nombre', '')
		item['rut'] = rut or item.get('rut', '')
		item['email'] = email or item.get('email', '')
		item['telefono'] = telefono or item.get('telefono', '')
		
		try:
			item['sueldo'] = int(float(sueldo)) if sueldo != '' else item.get('sueldo', 0)
		except:
			item['sueldo'] = item.get('sueldo', 0)
		
		if fecha_contratacion:
			item['fecha_contratacion'] = fecha_contratacion
		
		# Actualizar contraseña con hash si se proporciona
		if contrasena:
			# validar complejidad antes de aceptar
			if not _password_valid(contrasena):
				messages.error(request, "🔒 La contraseña debe tener al menos 8 caracteres, incluir al menos un número y un carácter especial.")
				return redirect(f"{reverse('supervisores')}?edit={mid}")
			item['contrasena'] = make_password(contrasena)
		
		_save_supervisores(items)
		messages.success(request, "Supervisor actualizado correctamente.")
		return redirect('supervisores')
	# GET -> redirige a la página de lista con ?edit=mid
	return redirect(f"{reverse('supervisores')}?edit={mid}")

def supervisores_delete(request, mid):

	if request.method == 'POST':
		items = _load_supervisores()
		items = [m for m in items if m.get('id') != int(mid)]
		_save_supervisores(items)
	return redirect('supervisores')

def _obrero_file_path():
	data_dir = os.path.join(settings.BASE_DIR, 'data')
	os.makedirs(data_dir, exist_ok=True)
	return os.path.join(data_dir, 'obreros.json')

def _load_obreros():
	fn = _obrero_file_path()
	if not os.path.exists(fn):
		with open(fn, 'w', encoding='utf-8') as f:
			json.dump([], f, ensure_ascii=False, indent=2)
	with open(fn, 'r', encoding='utf-8') as f:
		try:
			return json.load(f)
		except json.JSONDecodeError:
			return []

def _save_obreros(items):
	fn = _obrero_file_path()
	with open(fn, 'w', encoding='utf-8') as f:
		json.dump(items, f, ensure_ascii=False, indent=2)

def _obrero_to_dict(o):
    return {
        'id': getattr(o, 'id_obrero'),
        'nombre_completo': getattr(o.id_trabajador, 'nombre', ''),
        'rut': getattr(o.id_trabajador, 'rut', ''),
        'telefono': getattr(o.id_trabajador, 'telefono', ''),
        'fecha_contratacion': getattr(o.id_trabajador, 'fecha_contratacion', ''),
        'salary': getattr(o.id_trabajador, 'sueldo', 0),
        'position': getattr(o.id_cargo, 'nombre_cargo', '') if getattr(o, 'id_cargo', None) else '',
        'cargo_id': getattr(o.id_cargo, 'id_cargo', '') if getattr(o, 'id_cargo', None) else ''
    }

def obreros_view(request):

	q = request.GET.get('q', '').strip()
	edit_id = request.GET.get('edit')
	items_qs = Obrero.objects.select_related('id_trabajador', 'id_cargo').all()
	if q:
		items_qs = items_qs.filter(
			dj_models.Q(id_trabajador__nombre__icontains=q) |
			dj_models.Q(id_trabajador__rut__icontains=q) |
			dj_models.Q(id_cargo__nombre_cargo__icontains=q)
		)
	items = [_obrero_to_dict(o) for o in items_qs]
	edit_item = None
	if edit_id:
		try:
			eid = int(edit_id)
			o = Obrero.objects.select_related('id_trabajador', 'id_cargo').filter(id_obrero=eid).first()
			if o:
				edit_item = _obrero_to_dict(o)
		except:
			edit_item = None

	# Obtener todos los cargos para el select
	cargos = Cargo.objects.all()
	context = {
		'items': items,
		'q': q,
		'edit_item': edit_item,
		'cargos': cargos
	}
	return render(request, 'templatesapp/obreros.html', context)

def obreros_add(request):

	if request.method == 'POST':
		nombre_completo = request.POST.get('nombre_completo', '').strip()
		rut = request.POST.get('rut', '').strip()
		telefono = request.POST.get('telefono', '').strip()
		fecha_contratacion = request.POST.get('fecha_contratacion', '').strip()
		salary = request.POST.get('salary', '').strip()
		cargo_id = request.POST.get('position', '').strip()

		# Guardar form_data en sesión para repoblar en caso de error
		request.session['form_data'] = {
			'nombre_completo': nombre_completo,
			'rut': rut,
			'telefono': telefono,
			'fecha_contratacion': fecha_contratacion,
			'salary': salary,
			'position': cargo_id
		}

		# Validaciones básicas
		if not nombre_completo:
			messages.error(request, 'El nombre completo es obligatorio.')
			return redirect('obreros')
		if not rut:
			messages.error(request, 'El RUT es obligatorio.')
			return redirect('obreros')
		if Trabajador.objects.filter(rut__iexact=rut).exists():
			messages.error(request, 'El RUT ya está registrado.')
			return redirect('obreros')

		# validar salary
		try:
			salary_val = int(float(salary)) if salary != '' else None
		except Exception:
			messages.error(request, 'Sueldo inválido. Use un número válido.')
			return redirect('obreros')

		# Crear Trabajador
		trab = Trabajador.objects.create(
			nombre=nombre_completo,
			rut=rut,
			telefono=telefono,
			fecha_contratacion=fecha_contratacion or None,
			sueldo=salary_val
		)

		# Obtener cargo
		cargo = None
		if cargo_id:
			try:
				cargo = Cargo.objects.get(id_cargo=int(cargo_id))
			except Cargo.DoesNotExist:
				cargo = None

		# Crear Obrero
		Obrero.objects.create(
			id_trabajador=trab,
			id_cargo=cargo
		)
		if 'form_data' in request.session:
			del request.session['form_data']
		messages.success(request, 'Obrero creado correctamente.')
	return redirect('obreros')

def obreros_edit(request, mid):

	mid = int(mid)
	o = Obrero.objects.select_related('id_trabajador','id_cargo').filter(id_obrero=mid).first()
	if not o:
		raise Http404("Obrero no encontrado")
	if request.method == 'POST':
		# aceptar varios nombres de campo por compatibilidad
		nombre = request.POST.get('nombre_completo', '').strip() or request.POST.get('nombre', '').strip()
		# actualizar trabajador
		ob = o.id_trabajador
		ob.nombre = nombre
		new_rut = request.POST.get('rut', '').strip()
		ob.telefono = request.POST.get('telefono', '').strip()
		# usar el campo 'salary' que envía la plantilla
		salary = request.POST.get('salary', '').strip()
		# Validaciones
		if new_rut and Trabajador.objects.filter(rut__iexact=new_rut).exclude(id_trabajador=ob.id_trabajador).exists():
			messages.error(request, 'El RUT ya está registrado por otro trabajador.')
			return redirect(f"{reverse('obreros')}?edit={mid}")
		try:
			ob.sueldo = int(float(salary)) if salary != '' else None
		except Exception:
			messages.error(request, 'Sueldo inválido. Use un número válido.')
			return redirect(f"{reverse('obreros')}?edit={mid}")
		ob.rut = new_rut or ob.rut
		ob.fecha_contratacion = request.POST.get('fecha_contratacion', '').strip() or None
		ob.save()

		# actualizar cargo usando el name="position" del select
		cargo_id = request.POST.get('position', '').strip()
		if cargo_id:
			try:
				o.id_cargo = Cargo.objects.get(id_cargo=int(cargo_id))
			except Cargo.DoesNotExist:
				o.id_cargo = None
		else:
			o.id_cargo = None
		o.save()
		messages.success(request, 'Obrero actualizado correctamente.')
		return redirect('obreros')
	# GET -> redirige a la página de lista con ?edit=mid
	return redirect(f"{reverse('obreros')}?edit={mid}")

def obreros_delete(request, mid):
	if request.method == 'POST':
		# validar id
		try:
			mid_int = int(mid)
		except Exception:
			messages.error(request, 'ID de obrero inválido.')
			return redirect('obreros')

		o = Obrero.objects.filter(id_obrero=mid_int).first()
		if o:
			# Verificar préstamos que referencian este obrero
			if PrestamoHerramienta.objects.filter(id_obrero=mid_int).exists():
				messages.error(request, 'No se puede eliminar el obrero: existen préstamos que lo referencian. Finalice o reasigne esos préstamos antes de eliminar.')
			else:
				# eliminar obrero y, si corresponde, el trabajador asociado si no tiene otras referencias
				trab = o.id_trabajador
				o.delete()
				try:
					# comprobar referencias del trabajador
					has_bodeguero = Bodeguero.objects.filter(id_trabajador=trab).exists()
					has_obrero = Obrero.objects.filter(id_trabajador=trab).exists()
					has_supervisor = Supervisor.objects.filter(id_trabajador=trab).exists()
					if not (has_bodeguero or has_obrero or has_supervisor):
						trab.delete()
				except Exception:
					# si falla la eliminación del trabajador, simplemente continuar
					pass
	return redirect('obreros')

def login_view(request):
    if request.method == 'POST':
        username = request.POST.get('username', '').strip()
        password = request.POST.get('password', '')
        
        # Obtener credenciales desde variables de entorno
        admin_username = os.getenv('ADMIN_USERNAME', 'admin@gmail.com')
        admin_password = os.getenv('ADMIN_PASSWORD', 'adminuno123@')
        supervisor_username = os.getenv('SUPERVISOR_USERNAME', 'super@gmail.com')
        supervisor_password = os.getenv('SUPERVISOR_PASSWORD', 'super')
        
        if username == admin_username and password == admin_password:
            # Establecer sesión para admin
            request.session['user_type'] = 'admin'
            request.session['username'] = username
            return redirect('dashboard')
        elif username == supervisor_username and password == supervisor_password:
            # Establecer sesión para supervisor
            request.session['user_type'] = 'supervisor'
            request.session['username'] = username
            return redirect('supervisor_dashboard')
        else:
            # Buscar bodeguero por email y contraseña (usando check_password)
            try:
                trabajador = Trabajador.objects.get(email=username)
                # Validar contraseña hasheada
                if check_password(password, trabajador.contrasena):
                    bodeguero = Bodeguero.objects.filter(id_trabajador=trabajador).first()
                    if bodeguero:
                        # Establecer sesión para bodeguero
                        request.session['user_type'] = 'bodeguero'
                        request.session['username'] = username
                        request.session['bodeguero_id'] = bodeguero.id_bodeguero
                        # redirigir según si es central o local
                        if getattr(bodeguero, 'es_central', False):
                            return redirect('bodeguero_central')
                        else:
                            return redirect('bodeguerolo')
            except Trabajador.DoesNotExist:
                pass
                
        return render(request, 'templatesapp/login.html', {'login_error': True, 'username': username})
    return render(request, 'templatesapp/login.html')

def logout_view(request):
    # Limpiar toda la sesión
    if hasattr(request, 'session'):
        request.session.flush()
    # Limpiar cookies
    response = redirect('login')
    response.delete_cookie('sessionid')
    return response

# Helpers para actividades y proyectos
def _load_resource(name):
    data_dir = os.path.join(settings.BASE_DIR, 'data')
    os.makedirs(data_dir, exist_ok=True)
    fn = os.path.join(data_dir, f'{name}.json')
    if not os.path.exists(fn):
        with open(fn, 'w', encoding='utf-8') as f:
            json.dump([], f, ensure_ascii=False, indent=2)
    with open(fn, 'r', encoding='utf-8') as f:
        try:
            return json.load(f)
        except json.JSONDecodeError:
            return []

def _save_resource(name, items):
    data_dir = os.path.join(settings.BASE_DIR, 'data')
    fn = os.path.join(data_dir, f'{name}.json')
    with open(fn, 'w', encoding='utf-8') as f:
        json.dump(items, f, ensure_ascii=False, indent=2)

# Vistas del supervisor
def supervisor_dashboard(request):
    actividades = _load_resource('actividades')
    proyectos = _load_resource('proyectos')
    context = {
        'actividades': actividades,
        'proyectos': proyectos,
        'q': request.GET.get('q', ''),
    }
    return render(request, 'templatesapp/super.html', context)

# CRUD Actividades
def actividad_add(request):
    if request.method == 'POST':
        items = _load_resource('actividades')
        next_id = max([m.get('id', 0) for m in items], default=0) + 1
        items.append({
            'id': next_id,
            'nombre': request.POST.get('nombre', '').strip(),
            'fecha_inicio': request.POST.get('fecha_inicio', ''),
            'fecha_termino': request.POST.get('fecha_termino', ''),
            'descripcion': request.POST.get('descripcion', '').strip()
        })
        _save_resource('actividades', items)
    return redirect('supervisor_dashboard')

def actividad_edit(request, aid):
    items = _load_resource('actividades')
    item = next((a for a in items if a.get('id') == aid), None)
    if not item:
        raise Http404("Actividad no encontrada")
    if request.method == 'POST':
        item.update({
            'nombre': request.POST.get('nombre', '').strip(),
            'fecha_inicio': request.POST.get('fecha_inicio', ''),
            'fecha_termino': request.POST.get('fecha_termino', ''),
            'descripcion': request.POST.get('descripcion', '').strip()
        })
        _save_resource('actividades', items)
        return redirect('supervisor_dashboard')
    return redirect(f"{reverse('supervisor_dashboard')}?edit_actividad={aid}")

def actividad_delete(request, aid):
    if request.method == 'POST':
        items = _load_resource('actividades')
        items = [a for a in items if a.get('id') != aid]
        _save_resource('actividades', items)
    return redirect('supervisor_dashboard')

# CRUD Proyectos
def proyecto_add(request):
    if request.method == 'POST':
        items = _load_resource('proyectos')
        next_id = max([p.get('id', 0) for p in items], default=0) + 1
        try:
            metros = float(request.POST.get('metros', '0'))
            presupuesto = float(request.POST.get('presupuesto', '0'))
            avance = float(request.POST.get('avance', '0'))
        except ValueError:
            metros = 0
            presupuesto = 0
            avance = 0
            
        items.append({
            'id': next_id,
            'nombre': request.POST.get('nombre', '').strip(),
            'metros': metros,
            'direccion': request.POST.get('direccion', '').strip(),
            'presupuesto': presupuesto,
            'avance': avance,
            'fecha_inicio': request.POST.get('fecha_inicio', ''),
            'fecha_termino_est': request.POST.get('fecha_termino_est', ''),
            'fecha_termino_real': request.POST.get('fecha_termino_real', ''),
            'estado': request.POST.get('estado', '').strip()
        })
        _save_resource('proyectos', items)
    return redirect('supervisor_dashboard')

def proyecto_edit(request, pid):
    items = _load_resource('proyectos')
    item = next((p for p in items if p.get('id') == pid), None)
    if not item:
        raise Http404("Obra no encontrada")
    if request.method == 'POST':
        try:
            metros = float(request.POST.get('metros', '0'))
            presupuesto = float(request.POST.get('presupuesto', '0'))
            avance = float(request.POST.get('avance', '0'))
        except ValueError:
            metros = 0
            presupuesto = 0
            avance = 0
            
        item.update({
            'nombre': request.POST.get('nombre', '').strip(),
            'metros': metros,
            'direccion': request.POST.get('direccion', '').strip(),
            'presupuesto': presupuesto,
            'avance': avance,
            'fecha_inicio': request.POST.get('fecha_inicio', ''),
            'fecha_termino_est': request.POST.get('fecha_termino_est', ''),
            'fecha_termino_real': request.POST.get('fecha_termino_real', ''),
            'estado': request.POST.get('estado', '').strip()
        })
        _save_resource('proyectos', items)
        return redirect('supervisor_dashboard')
    return redirect(f"{reverse('supervisor_dashboard')}?edit_proyecto={pid}")

def proyecto_delete(request, pid):
    if request.method == 'POST':
        items = _load_resource('proyectos')
        items = [p for p in items if p.get('id') != pid]
        _save_resource('proyectos', items)
    return redirect('supervisor_dashboard')

def bodeguero_lo_view(request):
    return render(request, 'templatesapp/BodegueroLo.html')


def prestamos_view(request):

    q = request.GET.get('q', '').strip()
    items_qs = Obrero.objects.select_related('id_trabajador', 'id_cargo').all()

    if q:
        items_qs = items_qs.filter(
            dj_models.Q(id_trabajador__nombre__icontains=q) |
            dj_models.Q(id_trabajador__rut__icontains=q) |
            dj_models.Q(id_cargo__nombre_cargo__icontains=q)
        )

    obreros = [_obrero_to_dict(o) for o in items_qs]

    # Obtener bodega del bodeguero local (si es bodeguero en sesión)
    bodega = None
    user_type = request.session.get('user_type')
    bodeguero_id = request.session.get('bodeguero_id')

    if user_type == 'bodeguero' and bodeguero_id:
        bodeguero = Bodeguero.objects.select_related('id_bodega').filter(
            id_bodeguero=bodeguero_id
        ).first()
        if bodeguero:
            bodega = bodeguero.id_bodega

    # Herramientas según rol
    herramientas_qs = Herramienta.objects.select_related(
        'id_marca', 'id_tipo_herramienta'
    ).all()

    herramientas = []
    for h in herramientas_qs:
        hd = _herramienta_to_dict(h)

        if bodega:
            hb = HerramientaBodega.objects.filter(
                id_herramienta=h, id_bodega=bodega
            ).first()
            hd['stock_disponible'] = hb.stock_bodega if hb else 0
        else:
            hd['stock_disponible'] = h.stock_total

        herramientas.append(hd)

    # Préstamos pendientes
    pendientes = PrestamoHerramienta.objects.filter(
        estado='pendiente'
    ).select_related('id_obrero', 'id_herramienta')

    prestamo_por_obrero = {}
    prestamo_info = {}

    for p in pendientes:
        obrero_id = getattr(p.id_obrero, 'id_obrero')
        prestamo_por_obrero[obrero_id] = p.id_prestamo

        herr = p.id_herramienta
        prestamo_info[p.id_prestamo] = {
            'herramienta_nombre': getattr(herr, 'nombre_herramienta', '') if herr else '',
            'cantidad': p.cantidad or 0
        }

    # Adjuntar info de préstamo a cada obrero
    for o in obreros:
        pid = prestamo_por_obrero.get(o['id'])
        o['prestamo_id'] = pid

        if pid:
            info = prestamo_info.get(pid, {})
            o['prestamo_herramienta'] = info.get('herramienta_nombre', '')
            o['prestamo_cantidad'] = info.get('cantidad', 0)
        else:
            o['prestamo_herramienta'] = ''
            o['prestamo_cantidad'] = 0

        # Último estado de devolución del obrero
        try:
            last_completed = PrestamoHerramienta.objects.filter(
                id_obrero__id_obrero=o['id'],
                estado='completado'
            ).order_by('-fecha_devolucion').select_related('id_obrero').first()

            if last_completed and last_completed.estado_devolucion:
                o['ultimo_estado_devolucion'] = last_completed.estado_devolucion
            else:
                o['ultimo_estado_devolucion'] = ''
        except Exception:
            o['ultimo_estado_devolucion'] = ''

    # Histórico de préstamos completados
    completados = PrestamoHerramienta.objects.filter(
        estado='completado'
    ).select_related(
        'id_obrero',
        'id_herramienta',
        'id_bodeguero__id_trabajador'
    ).order_by('-fecha_devolucion')[:20]

    historico = []
    for p in completados:
        hist = {
            'id_prestamo': p.id_prestamo,
            'obrero_nombre': getattr(p.id_obrero.id_trabajador, 'nombre', '') if p.id_obrero else '',
            'herramienta_nombre': getattr(p.id_herramienta, 'nombre_herramienta', '') if p.id_herramienta else '',
            'cantidad': p.cantidad or 0,
            'fecha_prestamo': p.fecha_prestamo,
            'fecha_devolucion': p.fecha_devolucion,
            'estado_devolucion': p.estado_devolucion or 'no_registrado'
        }
        historico.append(hist)

    context = {
        'obreros': obreros,
        'herramientas': herramientas,
        'q': q,
        'prestamo_por_obrero': prestamo_por_obrero,
        'prestamo_info': prestamo_info,
        'bodega': bodega,
        'historico': historico,
        'estado_devolucion_choices': ESTADO_DEVOLUCION_CHOICES,
        'estado_devolucion_colors': ESTADO_DEVOLUCION_COLORS,
    }

    return render(request, 'templatesapp/prestamo.html', context)


def realizar_prestamo(request):

    prestamo_id = None
    if request.method == 'POST':
        obrero_id = request.POST.get('obrero_id')
        herramienta_id = request.POST.get('herramienta_id')
        cantidad = request.POST.get('cantidad', '1')

        try:
            obrero = Obrero.objects.get(id_obrero=int(obrero_id))
            herramienta = Herramienta.objects.get(id_herramienta=int(herramienta_id))
            cantidad_val = max(1, int(cantidad))

            # Determinar si es bodeguero local y obtener su bodega
            bodega = None
            user_type = request.session.get('user_type')
            bodeguero_id = request.session.get('bodeguero_id')
            if user_type == 'bodeguero' and bodeguero_id:
                bodeguero = Bodeguero.objects.select_related('id_bodega').filter(id_bodeguero=bodeguero_id).first()
                if bodeguero:
                    bodega = bodeguero.id_bodega

            if bodega:
                # Bodeguero local: validar y reducir desde HerramientaBodega
                hb = HerramientaBodega.objects.filter(id_herramienta=herramienta, id_bodega=bodega).first()
                stock_disponible = hb.stock_bodega if hb else 0
                if stock_disponible >= cantidad_val:
                    # Reducir stock de bodega
                    if not hb:
                        hb = HerramientaBodega(id_herramienta=herramienta, id_bodega=bodega, stock_bodega=0)
                    hb.stock_bodega = stock_disponible - cantidad_val
                    hb.save()

                    # Crear registro de préstamo
                    prestamo = PrestamoHerramienta.objects.create(
                        id_herramienta_bodega=None,
                        id_herramienta=herramienta,
                        id_obrero=obrero,
                        fecha_prestamo=timezone.now().date(),
                        estado='pendiente',
                        cantidad=cantidad_val
                    )
                    prestamo_id = prestamo.id_prestamo
            else:
                # Admin/Supervisor: validar y reducir desde Herramienta.stock_total
                if herramienta.stock_total >= cantidad_val:
                    # Reducir inventario inmediatamente
                    herramienta.stock_total -= cantidad_val
                    herramienta.save()

                    # Crear registro de préstamo en estado PENDIENTE con cantidad
                    prestamo = PrestamoHerramienta.objects.create(
                        id_herramienta_bodega=None,
                        id_herramienta=herramienta,
                        id_obrero=obrero,
                        fecha_prestamo=timezone.now().date(),
                        estado='pendiente',
                        cantidad=cantidad_val
                    )
                    prestamo_id = prestamo.id_prestamo
        except (Obrero.DoesNotExist, Herramienta.DoesNotExist, ValueError):
            pass

    if prestamo_id:
        return redirect(f"{reverse('prestamos')}?prestamo_id={prestamo_id}")
    return redirect('prestamos')

# --- vistas específicas para bodegueros: ver y ajustar cantidades ---
def materials_bodeguero_view(request):

	# obtener bodeguero asignado en sesión
	bodeguero_id = request.session.get('bodeguero_id')
	if not bodeguero_id:
		return redirect('login')
	bodeguero = Bodeguero.objects.select_related('id_bodega').filter(id_bodeguero=bodeguero_id).first()
	if not bodeguero or not bodeguero.id_bodega:
		messages.error(request, 'No tienes una bodega asignada. Contacta al administrador.')
		return render(request, 'templatesapp/materials_bodeguero.html', {'materials': [], 'q': ''})

	bodega = bodeguero.id_bodega

	if request.method == 'POST':
		mat_id = request.POST.get('id')
		action = request.POST.get('action')
		amount = request.POST.get('amount', '1')
		try:
			amt = max(1, int(amount))
		except:
			amt = 1
		try:
			mat = Material.objects.get(id_material=int(mat_id))
			mb = MaterialBodega.objects.filter(id_material=mat, id_bodega=bodega).first()
			if not mb:
				# si no existe, crear con 0 antes de aplicar
				mb = MaterialBodega(id_material=mat, id_bodega=bodega, stock_bodega=0)
			if action == 'add':
				mb.stock_bodega = (mb.stock_bodega or 0) + amt
			elif action == 'sub':
				mb.stock_bodega = max(0, (mb.stock_bodega or 0) - amt)
			mb.save()
		except Material.DoesNotExist:
			pass
		return redirect('bodeguero_materials')

	# GET
	q = request.GET.get('q', '').strip()
	items_qs = Material.objects.select_related('id_marca','id_tipo_material').all()
	if q:
		items_qs = items_qs.filter(
			dj_models.Q(nombre_material__icontains=q) |
			dj_models.Q(descripcion_material__icontains=q) |
			dj_models.Q(id_marca__nombre_marca__icontains=q)
		)

	materials = []
	for m in items_qs:
		md = _material_to_dict(m)
		mb = MaterialBodega.objects.filter(id_material=m, id_bodega=bodega).first()
		md['stock_bodega'] = mb.stock_bodega if mb else 0
		materials.append(md)

	return render(request, 'templatesapp/materials_bodeguero.html', {'materials': materials, 'q': q, 'bodega': bodega})

def finalizar_prestamo(request):

    if request.method == 'POST':
        prestamo_id = request.POST.get('prestamo_id')
        try:
            prestamo = PrestamoHerramienta.objects.get(id_prestamo=int(prestamo_id))
            if prestamo.estado == 'pendiente':
                # Obtener la herramienta y la cantidad
                herramienta = prestamo.id_herramienta
                cantidad = prestamo.cantidad or 0

                # Determinar si es bodeguero local y obtener su bodega
                bodega = None
                user_type = request.session.get('user_type')
                bodeguero_id = request.session.get('bodeguero_id')
                if user_type == 'bodeguero' and bodeguero_id:
                    bodeguero = Bodeguero.objects.select_related('id_bodega').filter(id_bodeguero=bodeguero_id).first()
                    if bodeguero:
                        bodega = bodeguero.id_bodega

                if herramienta and cantidad > 0:
                    if bodega:
                        # Bodeguero local: incrementar desde HerramientaBodega
                        hb = HerramientaBodega.objects.filter(id_herramienta=herramienta, id_bodega=bodega).first()
                        if not hb:
                            hb = HerramientaBodega(id_herramienta=herramienta, id_bodega=bodega, stock_bodega=0)
                        hb.stock_bodega = (hb.stock_bodega or 0) + cantidad
                        hb.save()
                    else:
                        # Admin/Supervisor: incrementar desde Herramienta.stock_total
                        herramienta.stock_total = (herramienta.stock_total or 0) + cantidad
                        herramienta.save()
                
                # Marcar como completado y registrar estado de devolución
                prestamo.estado = 'completado'
                prestamo.estado_devolucion = request.POST.get('estado_devolucion') or prestamo.estado_devolucion
                prestamo.fecha_devolucion = timezone.now().date()
                # Registrar id_bodeguero si la acción la realiza un bodeguero
                if user_type == 'bodeguero' and bodeguero_id and 'bodeguero' in locals() and bodeguero:
                    try:
                        prestamo.id_bodeguero = bodeguero
                    except Exception:
                        pass
                prestamo.save()
        except (PrestamoHerramienta.DoesNotExist, ValueError) as e:
            print(f"Error al finalizar préstamo: {e}")
    
    return redirect('prestamos')

def herramientas_bodeguero_view(request):

	bodeguero_id = request.session.get('bodeguero_id')
	if not bodeguero_id:
		return redirect('login')
	bodeguero = Bodeguero.objects.select_related('id_bodega').filter(id_bodeguero=bodeguero_id).first()
	if not bodeguero or not bodeguero.id_bodega:
		messages.error(request, 'No tienes una bodega asignada. Contacta al administrador.')
		return render(request, 'templatesapp/resource_bodeguero.html', {'items': [], 'q': ''})

	bodega = bodeguero.id_bodega

	if request.method == 'POST':
		tool_id = request.POST.get('id')
		action = request.POST.get('action')
		amount = request.POST.get('amount', '1')
		try:
			amt = max(1, int(amount))
		except:
			amt = 1
		try:
			h = Herramienta.objects.get(id_herramienta=int(tool_id))
			hb = HerramientaBodega.objects.filter(id_herramienta=h, id_bodega=bodega).first()
			if not hb:
				hb = HerramientaBodega(id_herramienta=h, id_bodega=bodega, stock_bodega=0)
			if action == 'add':
				hb.stock_bodega = (hb.stock_bodega or 0) + amt
			elif action == 'sub':
				hb.stock_bodega = max(0, (hb.stock_bodega or 0) - amt)
			hb.save()
		except Herramienta.DoesNotExist:
			pass
		return redirect('bodeguero_herramientas')

	# GET
	q = request.GET.get('q', '').strip()
	items_qs = Herramienta.objects.select_related('id_marca','id_tipo_herramienta').all()
	if q:
		items_qs = items_qs.filter(
			dj_models.Q(nombre_herramienta__icontains=q) |
			dj_models.Q(descripcion_herramienta__icontains=q) |
			dj_models.Q(id_marca__nombre_marca__icontains=q)
		)

	herramientas = []
	for h in items_qs:
		hd = _herramienta_to_dict(h)
		hb = HerramientaBodega.objects.filter(id_herramienta=h, id_bodega=bodega).first()
		hd['stock_bodega'] = hb.stock_bodega if hb else 0
		herramientas.append(hd)

	return render(request, 'templatesapp/resource_bodeguero.html', {'items': herramientas, 'q': q, 'bodega': bodega})


def bodeguero_ce_view(request):

	# permiso: sólo bodegueros centrales
	user_type = request.session.get('user_type')
	if user_type != 'bodeguero':
		messages.error(request, 'Acceso denegado: sólo bodegueros centrales pueden ver este panel.')
		return redirect('login')
	bodeguero_id = request.session.get('bodeguero_id')
	if not bodeguero_id:
		messages.error(request, 'Acceso denegado: no tienes sesión de bodeguero.')
		return redirect('login')
	bodeg = Bodeguero.objects.filter(id_bodeguero=bodeguero_id).first()
	if not bodeg or not getattr(bodeg, 'es_central', False):
		messages.error(request, 'Acceso denegado: no eres un bodeguero central.')
		return redirect('login')

	materials_qs = Material.objects.select_related('id_marca','id_tipo_material').all()
	herramientas_qs = Herramienta.objects.select_related('id_marca','id_tipo_herramienta').all()
	bodegas = Bodega.objects.all()

	materials = [_material_to_dict(m) for m in materials_qs]
	herramientas = [_herramienta_to_dict(h) for h in herramientas_qs]

	context = {
		'materials': materials,
		'herramientas': herramientas,
		'bodegas': bodegas
	}
	return render(request, 'templatesapp/BodegueroCe.html', context)


def bodeguero_ce_allocate_material(request):

	# permiso: sólo bodegueros centrales
	user_type = request.session.get('user_type')
	bodeguero_id = request.session.get('bodeguero_id')
	if user_type != 'bodeguero' or not bodeguero_id:
		messages.error(request, 'Acceso denegado.')
		return redirect('login')
	bodeg = Bodeguero.objects.filter(id_bodeguero=bodeguero_id).first()
	if not bodeg or not getattr(bodeg, 'es_central', False):
		messages.error(request, 'Acceso denegado: sólo bodegueros centrales.')
		return redirect('login')

	if request.method == 'POST':
		try:
			mat_id = int(request.POST.get('material_id'))
			bodega_id = int(request.POST.get('bodega_id'))
			cantidad = int(request.POST.get('cantidad', '0'))
		except (TypeError, ValueError):
			messages.error(request, 'Entrada inválida para la asignación.')
			return redirect('bodeguero_central')

		if cantidad <= 0:
			messages.error(request, 'La cantidad debe ser mayor que cero.')
			return redirect('bodeguero_central')

		try:
			mat = Material.objects.get(id_material=mat_id)
			bodega = Bodega.objects.get(id_bodega=bodega_id)
		except (Material.DoesNotExist, Bodega.DoesNotExist):
			messages.error(request, 'Material o bodega no encontrado.')
			return redirect('bodeguero_central')

		# verificar stock central disponible
		central_stock = mat.stock_disponible or 0
		if central_stock < cantidad:
			messages.error(request, f'Stock central insuficiente. Disponible: {central_stock}')
			return redirect('bodeguero_central')

		# disminuir stock central
		mat.stock_disponible = central_stock - cantidad
		mat.save()

		# aumentar stock en MaterialBodega
		mb = MaterialBodega.objects.filter(id_material=mat, id_bodega=bodega).first()
		if not mb:
			mb = MaterialBodega(id_material=mat, id_bodega=bodega, stock_bodega=0)
		mb.stock_bodega = (mb.stock_bodega or 0) + cantidad
		mb.save()

		messages.success(request, f'{cantidad} de "{mat.nombre_material}" asignados a {bodega.nombre_bodega}.')
	return redirect('bodeguero_central')


def bodeguero_ce_allocate_herramienta(request):
	# Solo bodegueros centrales
	user_type = request.session.get('user_type')
	bodeguero_id = request.session.get('bodeguero_id')
	if user_type != 'bodeguero' or not bodeguero_id:
		messages.error(request, 'Acceso denegado.')
		return redirect('login')
	bodeg = Bodeguero.objects.filter(id_bodeguero=bodeguero_id).first()
	if not bodeg or not getattr(bodeg, 'es_central', False):
		messages.error(request, 'Acceso denegado: sólo bodegueros centrales.')
		return redirect('login')

	if request.method == 'POST':
		try:
			herr_id = int(request.POST.get('herramienta_id'))
			bodega_id = int(request.POST.get('bodega_id'))
			cantidad = int(request.POST.get('cantidad', '0'))
		except (TypeError, ValueError):
			messages.error(request, 'Entrada inválida para la asignación.')
			return redirect('bodeguero_central')

		if cantidad <= 0:
			messages.error(request, 'La cantidad debe ser mayor que cero.')
			return redirect('bodeguero_central')

		try:
			herr = Herramienta.objects.get(id_herramienta=herr_id)
			bodega = Bodega.objects.get(id_bodega=bodega_id)
		except (Herramienta.DoesNotExist, Bodega.DoesNotExist):
			messages.error(request, 'Herramienta o bodega no encontrado.')
			return redirect('bodeguero_central')

		central_stock = herr.stock_total or 0
		if central_stock < cantidad:
			messages.error(request, f'Stock central insuficiente. Disponible: {central_stock}')
			return redirect('bodeguero_central')

		herr.stock_total = central_stock - cantidad
		herr.save()

		hb = HerramientaBodega.objects.filter(id_herramienta=herr, id_bodega=bodega).first()
		if not hb:
			hb = HerramientaBodega(id_herramienta=herr, id_bodega=bodega, stock_bodega=0)
		hb.stock_bodega = (hb.stock_bodega or 0) + cantidad
		hb.save()

		messages.success(request, f'{cantidad} de "{herr.nombre_herramienta}" asignadas a {bodega.nombre_bodega}.')
	return redirect('bodeguero_central')