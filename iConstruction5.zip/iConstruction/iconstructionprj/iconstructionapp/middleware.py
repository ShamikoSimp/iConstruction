# iconstructionapp/middleware.py
from django.shortcuts import redirect
from django.urls import reverse

class SessionProtectionMiddleware:
    """
    Middleware que protege las vistas administrativas requiriendo sesión activa.
    Redirige a login si la sesión no está establecida.
    """
    
    # Rutas públicas que NO requieren sesión
    PUBLIC_URLS = [
        reverse('login'),
    ]
    
    # Rutas protegidas que requieren sesión
    PROTECTED_URLS = [
        '/dashboard/',
        '/materials/',
        '/herramientas/',
        '/bodegas/',
        '/bodegueros/',
        '/supervisores/',
        '/obreros/',
        '/supervisor/',
        '/bodeguerolo/',
        '/prestamos/',
        '/realizar-prestamo/',
        '/finalizar-prestamo/',
        '/bodeguero/',
    ]
    
    def __init__(self, get_response):
        self.get_response = get_response
    
    def __call__(self, request):
        # Obtener la ruta actual
        path = request.path
        
        # Si es una ruta protegida y no hay sesión válida, redirigir a login
        if self._is_protected_url(path) and not self._has_valid_session(request):
            return redirect('login')
        
        response = self.get_response(request)
        return response
    
    def _is_protected_url(self, path):
        # Verifica si la URL está en la lista de protegidas
        for protected in self.PROTECTED_URLS:
            if path.startswith(protected):
                return True
        return False
    
    def _has_valid_session(self, request):
        # Verifica si hay una sesión válida establecida
        # Verificar si existe user_type en la sesión
        return 'user_type' in request.session and request.session.get('user_type') is not None
