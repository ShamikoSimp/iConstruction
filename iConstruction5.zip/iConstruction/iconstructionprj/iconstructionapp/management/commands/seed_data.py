from django.core.management.base import BaseCommand
from iconstructionapp.models import (
    RegionBodega, MarcaHerramienta, CategoriaHerramienta, TipoHerramienta,
    TipoBodega, EstadoHerramienta, MarcaMaterial, TipoMaterial, Cargo
)


class Command(BaseCommand):
    help = 'Carga los datos iniciales (datos dinámicos) a la base de datos'

    def handle(self, *args, **options):
        # DATOS DINÁMICOS (se pueden agregar/editar/eliminar desde UI)
        
        # Marcas Herramienta
        marcas_herr = ['Bauker', 'Ubermann', 'Makita', 'Stanley']
        for nombre in marcas_herr:
            MarcaHerramienta.objects.get_or_create(nombre_marca=nombre)
        self.stdout.write(self.style.SUCCESS(f'[OK] {len(marcas_herr)} marcas de herramientas creadas/actualizadas'))

        # Tipos Herramienta
        tipos_herr = ['Electrica', 'Manual']
        for nombre in tipos_herr:
            TipoHerramienta.objects.get_or_create(nombre_tipo_herramienta=nombre)
        self.stdout.write(self.style.SUCCESS(f'[OK] {len(tipos_herr)} tipos de herramientas creados/actualizados'))

        # Tipos Material
        tipos_mat = ['Petreo', 'Ceramico', 'Metalico', 'Madera']
        for nombre in tipos_mat:
            TipoMaterial.objects.get_or_create(nombre_tipo_material=nombre)
        self.stdout.write(self.style.SUCCESS(f'[OK] {len(tipos_mat)} tipos de material creados/actualizados'))

        # Marcas Material
        marcas_mat = ['Makita', 'Pladur', 'Ternium']
        for nombre in marcas_mat:
            MarcaMaterial.objects.get_or_create(nombre_marca=nombre)
        self.stdout.write(self.style.SUCCESS(f'[OK] {len(marcas_mat)} marcas de materiales creadas/actualizadas'))

        # Cargos
        cargos = ['Capataz', 'Oficial', 'Ayudante']
        for nombre in cargos:
            Cargo.objects.get_or_create(nombre_cargo=nombre)
        self.stdout.write(self.style.SUCCESS(f'[OK] {len(cargos)} cargos creados/actualizados'))

        # Regiones
        regiones = [
            'Arica y Parinacota', 'Tarapaca', 'Antofagasta', 'Atacama', 'Coquimbo',
            'Valparaiso', 'Metropolitana', 'O Higgins', 'Maule', 'Biobio',
            'Araucania', 'Los Rios', 'Los Lagos', 'Aysen', 'Magallanes'
        ]
        for nombre in regiones:
            RegionBodega.objects.get_or_create(nombre_region=nombre)
        self.stdout.write(self.style.SUCCESS(f'[OK] {len(regiones)} regiones creadas/actualizadas'))

        # Categorías Herramienta
        categorias = ['Martillo', 'Taladro', 'Escalera']
        for nombre in categorias:
            CategoriaHerramienta.objects.get_or_create(nombre_categoria=nombre)
        self.stdout.write(self.style.SUCCESS(f'[OK] {len(categorias)} categorias creadas/actualizadas'))

        # DATOS ESTÁTICOS (hardcodeados en vistas/templates)
        # Tipos Bodega
        tipos_bodega = ['Local', 'Central']
        for nombre in tipos_bodega:
            TipoBodega.objects.get_or_create(nombre_tipo_bodega=nombre)
        self.stdout.write(self.style.SUCCESS(f'[OK] {len(tipos_bodega)} tipos de bodega creados/actualizados'))

        # Estados Herramienta
        estados = ['Entregado', 'Faltante']
        for nombre in estados:
            EstadoHerramienta.objects.get_or_create(nombre_estado=nombre)
        self.stdout.write(self.style.SUCCESS(f'[OK] {len(estados)} estados de herramienta creados/actualizados'))

        self.stdout.write(self.style.SUCCESS('\n[SUCCESS] Todos los datos iniciales se cargaron exitosamente'))

