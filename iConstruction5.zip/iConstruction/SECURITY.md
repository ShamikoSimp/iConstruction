# iConstruction - Variables de Entorno

## Configuración de Seguridad

Las credenciales del sistema ahora están protegidas usando variables de entorno en lugar de estar hardcodeadas en el código.

### Archivos Importantes

- **`.env`** - Contiene las credenciales (NO se versiona en git por seguridad)
- **`.gitignore`** - Protege archivos sensibles de ser commiteados

### Variables de Entorno Disponibles

```env
# Credenciales del Admin
ADMIN_USERNAME=admin@gmail.com
ADMIN_PASSWORD=admin

# Credenciales del Supervisor
SUPERVISOR_USERNAME=super@gmail.com
SUPERVISOR_PASSWORD=super
```

### Cambio de Credenciales

Para cambiar las credenciales:

1. Abre el archivo `.env` en la raíz del proyecto
2. Modifica los valores según sea necesario
3. Guarda el archivo
4. Reinicia el servidor Django

**Nota:** Nunca commitees el archivo `.env` a git. Solo debe estar en tu máquina local o en variables de entorno del servidor de producción.

### Instalación Inicial

El proyecto ya tiene `python-dotenv` instalado. Si necesitas reinstalar:

```bash
pip install python-dotenv
```

### En Producción

Para producción, establece las variables de entorno en el servidor o en la plataforma de hosting:

- **Heroku**: Usa el panel de configuración para variables de entorno
- **AWS/Azure**: Usa los servicios de gestión de secretos
- **Servidores propios**: Configura en el archivo de ambiente del servidor

Nunca publiques credenciales en código o repositorios públicos.
