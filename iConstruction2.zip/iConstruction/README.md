# iConstruction - Manual de Usuario

## Índice
1. Acceso al Sistema
2. Panel de Administrador
3. Panel de Supervisor
4. Gestión de Materiales
5. Gestión de Herramientas
6. Gestión de Bodegas
7. Gestión de Personal
8. Gestión de Obras

## 1. Acceso al Sistema
- **Usuario Administrador**: 
  - Email: admin@gmail.com
  - Contraseña: admin
- **Usuario Supervisor**:
  - Email: super@gmail.com
  - Contraseña: super

## 2. Panel de Administrador
Acceso a todas las funcionalidades del sistema:
- Gestión de materiales
- Gestión de herramientas
- Gestión de bodegas
- Gestión de bodegueros
- Gestión de supervisores
- Gestión de obreros

## 3. Panel de Supervisor
Acceso a:
- Gestión de actividades
- Gestión de obras

### 3.1 Gestión de Actividades
Permite administrar las actividades de obra con:
- Nombre
- Fecha de inicio
- Fecha de término
- Descripción

### 3.2 Gestión de Obras
Administración de obras con los siguientes datos:
- Nombre
- Metros cuadrados
- Dirección
- Presupuesto
- Porcentaje de avance
- Fecha de inicio
- Fecha estimada de término
- Fecha real de término
- Estado (No Iniciada/En Ejecución/Paralizada/Terminada)

## 4. Gestión de Materiales
Administración de materiales con:
- Nombre
- Precio
- Descripción
- Marca
- Tipo de material

## 5. Gestión de Herramientas
Control de herramientas con:
- Nombre
- Precio
- Dimensiones
- Tipo de herramienta
- Nombre de la marca

## 6. Gestión de Bodegas
Administración de bodegas con:
- Nombre
- Dirección
- Capacidad
- Tipo de bodega

## 7. Gestión de Personal

### 7.1 Bodegueros
Registro de bodegueros con:
- Nombre
- Apellido
- Sueldo
- Bodega asignada

### 7.2 Supervisores
Control de supervisores con:
- Nombre
- Sueldo
- Código de obra asignado

### 7.3 Obreros
Gestión de obreros con:
- Nombre
- Apellido
- Sueldo
- Años de servicio
- Cargo

## Funcionalidades Comunes
Todas las secciones incluyen:
- Búsqueda por texto
- Agregar nuevos registros
- Editar registros existentes
- Eliminar registros (con confirmación)
- Listado en tabla

## Notas Importantes
- Los datos se almacenan en archivos JSON dentro del directorio /data/
- Las búsquedas son sensibles a mayúsculas/minúsculas
- Los campos numéricos (precios, metros cuadrados, etc.) aceptan decimales
- El porcentaje de avance en obras debe estar entre 0 y 100
