from django.db import models

# Create your models here.
class Actividad(models.Model):
    id_actividad = models.AutoField(primary_key=True)
    nombre_actividad = models.CharField(max_length=50)
    descripcion_actividad = models.CharField(max_length=200)
    fecha_inicio = models.DateField(blank=True, null=True)
    fecha_termino = models.DateField(blank=True, null=True)

    class Meta:
         
        db_table = 'actividad'


class Bodega(models.Model):
    id_bodega = models.AutoField(primary_key=True)
    id_tipo_bodega = models.ForeignKey('TipoBodega', models.DO_NOTHING, db_column='id_tipo_bodega')
    nombre_bodega = models.CharField(max_length=50, blank=True, null=True)
    capacidad = models.IntegerField()
    direccion = models.CharField(max_length=200)

    class Meta:
         
        db_table = 'bodega'


class Bodeguero(models.Model):
    id_bodeguero = models.AutoField(primary_key=True)
    id_trabajador = models.OneToOneField('Trabajador', models.DO_NOTHING, db_column='id_trabajador')
    id_bodega = models.ForeignKey(Bodega, models.DO_NOTHING, db_column='id_bodega', blank=True, null=True)

    class Meta:
         
        db_table = 'bodeguero'


class Cargo(models.Model):
    id_cargo = models.AutoField(primary_key=True)
    nombre_cargo = models.CharField(max_length=25)

    class Meta:
         
        db_table = 'cargo'


class CategoriaHerramienta(models.Model):
    id_categoria = models.AutoField(primary_key=True)
    nombre_categoria = models.CharField(max_length=25)

    class Meta:
         
        db_table = 'categoria_herramienta'


class CategoriaObra(models.Model):
    id_categoria = models.AutoField(primary_key=True)
    nombre_categoria = models.CharField(max_length=25)

    class Meta:
         
        db_table = 'categoria_obra'


class Comuna(models.Model):
    id_comuna = models.AutoField(primary_key=True)
    nombre_comuna = models.CharField(max_length=25)

    class Meta:
         
        db_table = 'comuna'


class EstadoHerramienta(models.Model):
    id_estado = models.AutoField(primary_key=True)
    nombre_estado = models.CharField(max_length=25)

    class Meta:
         
        db_table = 'estado_herramienta'


class EstadoObra(models.Model):
    id_estado = models.AutoField(primary_key=True)
    nombre_estado = models.CharField(max_length=25)

    class Meta:
         
        db_table = 'estado_obra'


class Herramienta(models.Model):
    id_herramienta = models.AutoField(primary_key=True)
    id_estado = models.ForeignKey(EstadoHerramienta, models.DO_NOTHING, db_column='id_estado')
    id_categoria = models.ForeignKey(CategoriaHerramienta, models.DO_NOTHING, db_column='id_categoria')
    id_tipo_herramienta = models.ForeignKey('TipoHerramienta', models.DO_NOTHING, db_column='id_tipo_herramienta')
    id_marca = models.ForeignKey('MarcaHerramienta', models.DO_NOTHING, db_column='id_marca')
    nombre_herramienta = models.CharField(max_length=100)
    precio = models.DecimalField(max_digits=12, decimal_places=2, default=0)  # nuevo campo
    dimensiones = models.CharField(max_length=50, blank=True, null=True)
    # tipo de herramienta y nombre de la marca ya están como FK, pero puedes agregar redundancia si lo necesitas:
    # tipo_herramienta = models.CharField(max_length=25, blank=True, null=True)
    # nombre_marca = models.CharField(max_length=40, blank=True, null=True)
    descripcion_herramienta = models.TextField()
    stock_total = models.IntegerField()

    class Meta:
         
        db_table = 'herramienta'


class HerramientaBodega(models.Model):
    id_herramienta_bodega = models.AutoField(primary_key=True)
    id_herramienta = models.ForeignKey(Herramienta, models.DO_NOTHING, db_column='id_herramienta')
    id_bodega = models.ForeignKey(Bodega, models.DO_NOTHING, db_column='id_bodega')
    stock_bodega = models.IntegerField()

    class Meta:
         
        db_table = 'herramienta_bodega'


class Informe(models.Model):
    id_informe = models.AutoField(primary_key=True)
    id_supervisor = models.ForeignKey('Supervisor', models.DO_NOTHING, db_column='id_supervisor')
    id_tipo_informe = models.ForeignKey('TipoInforme', models.DO_NOTHING, db_column='id_tipo_informe')
    titulo_informe = models.CharField(max_length=100)
    fecha_informe = models.DateField()

    class Meta:
         
        db_table = 'informe'


class MarcaHerramienta(models.Model):
    id_marca = models.AutoField(primary_key=True)
    nombre_marca = models.CharField(max_length=40)

    class Meta:
         
        db_table = 'marca_herramienta'


class MarcaMaterial(models.Model):
    id_marca = models.AutoField(primary_key=True)
    nombre_marca = models.CharField(max_length=40)

    class Meta:
         
        db_table = 'marca_material'


class Material(models.Model):
    id_material = models.AutoField(primary_key=True)
    id_marca = models.ForeignKey(MarcaMaterial, models.DO_NOTHING, db_column='id_marca')
    id_tipo_material = models.ForeignKey('TipoMaterial', models.DO_NOTHING, db_column='id_tipo_material')
    nombre_material = models.CharField(max_length=100)
    descripcion_material = models.TextField()
    precio = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    stock_minimo = models.IntegerField(blank=True, null=True)
    stock_disponible = models.IntegerField()
    dimensiones = models.CharField(max_length=50, blank=True, null=True)
    fecha_vencimiento = models.DateField(blank=True, null=True)

    class Meta:
         
        db_table = 'material'


class MaterialBodega(models.Model):
    pk = models.CompositePrimaryKey('id_material', 'id_bodega')
    id_material = models.ForeignKey(Material, models.DO_NOTHING, db_column='id_material')
    id_bodega = models.ForeignKey(Bodega, models.DO_NOTHING, db_column='id_bodega')
    stock_bodega = models.IntegerField()

    class Meta:
         
        db_table = 'material_bodega'


class Obra(models.Model):
    id_obra = models.AutoField(primary_key=True)
    id_categoria = models.ForeignKey(CategoriaObra, models.DO_NOTHING, db_column='id_categoria')
    id_estado = models.ForeignKey(EstadoObra, models.DO_NOTHING, db_column='id_estado')
    id_comuna = models.ForeignKey(Comuna, models.DO_NOTHING, db_column='id_comuna')
    nombre_obra = models.CharField(max_length=100)
    direccion_obra = models.CharField(max_length=200)
    metros_cuadrados = models.DecimalField(max_digits=10, decimal_places=2)
    presupuesto = models.DecimalField(max_digits=15, decimal_places=2, blank=True, null=True)
    fecha_inicio = models.DateField()
    fecha_termino_estimada = models.DateField()
    fecha_termino_real = models.DateField(blank=True, null=True)

    class Meta:
         
        db_table = 'obra'


class Obrero(models.Model):
    id_obrero = models.AutoField(primary_key=True)
    id_trabajador = models.OneToOneField('Trabajador', models.DO_NOTHING, db_column='id_trabajador')
    id_obra = models.ForeignKey(Obra, models.DO_NOTHING, db_column='id_obra', blank=True, null=True)
    id_cargo = models.ForeignKey(Cargo, models.DO_NOTHING, db_column='id_cargo')
    id_actividad = models.ForeignKey(Actividad, models.DO_NOTHING, db_column='id_actividad', blank=True, null=True)

    class Meta:
         
        db_table = 'obrero'


class PrestamoHerramienta(models.Model):
    id_prestamo = models.AutoField(primary_key=True)
    id_herramienta_bodega = models.ForeignKey(HerramientaBodega, models.DO_NOTHING, db_column='id_herramienta_bodega')    
    id_obrero = models.ForeignKey(Obrero, models.DO_NOTHING, db_column='id_obrero')
    fecha_prestamo = models.DateField()
    fecha_devolucion = models.DateField(blank=True, null=True)

    class Meta:
         
        db_table = 'prestamo_herramienta'


class ReporteHerramienta(models.Model):
    id_reporte = models.AutoField(primary_key=True)
    id_tipo_reporte = models.ForeignKey('TipoReporte', models.DO_NOTHING, db_column='id_tipo_reporte')
    id_bodeguero = models.ForeignKey(Bodeguero, models.DO_NOTHING, db_column='id_bodeguero')
    id_herramienta = models.ForeignKey(Herramienta, models.DO_NOTHING, db_column='id_herramienta')
    nombre_reporte = models.CharField(max_length=100)
    descripcion_incidente = models.TextField()
    fecha_reporte = models.DateField()

    class Meta:
         
        db_table = 'reporte_herramienta'


class Supervisor(models.Model):
    id_supervisor = models.AutoField(primary_key=True)
    id_trabajador = models.OneToOneField('Trabajador', models.DO_NOTHING, db_column='id_trabajador')
    id_obra = models.ForeignKey(Obra, models.DO_NOTHING, db_column='id_obra', blank=True, null=True)

    class Meta:
         
        db_table = 'supervisor'


class TipoBodega(models.Model):
    id_tipo_bodega = models.AutoField(primary_key=True)
    nombre_tipo_bodega = models.CharField(max_length=15)

    class Meta:
         
        db_table = 'tipo_bodega'


class TipoHerramienta(models.Model):
    id_tipo_herramienta = models.AutoField(primary_key=True)
    nombre_tipo_herramienta = models.CharField(max_length=25)

    class Meta:
         
        db_table = 'tipo_herramienta'


class TipoInforme(models.Model):
    id_tipo_informe = models.AutoField(primary_key=True)
    nombre_tipo_informe = models.CharField(max_length=30)

    class Meta:
         
        db_table = 'tipo_informe'


class TipoMaterial(models.Model):
    id_tipo_material = models.AutoField(primary_key=True)
    nombre_tipo_material = models.CharField(max_length=30)

    class Meta:
         
        db_table = 'tipo_material'


class TipoReporte(models.Model):
    id_tipo_reporte = models.AutoField(primary_key=True)
    nombre_tipo_reporte = models.CharField(max_length=30)

    class Meta:
         
        db_table = 'tipo_reporte'


class Trabajador(models.Model):
    id_trabajador = models.AutoField(primary_key=True)
    nombre = models.CharField(max_length=100)
    rut = models.CharField(unique=True, max_length=12)
    email = models.CharField(max_length=100, blank=True, null=True)
    telefono = models.CharField(max_length=20)
    sueldo = models.IntegerField(blank=True, null=True)
    fecha_contratacion = models.DateField()
    contrasena = models.CharField(max_length=128, blank=True, null=True) 

    class Meta:
         
        db_table = 'trabajador'