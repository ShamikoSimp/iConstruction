from django.shortcuts import render, redirect
from django.conf import settings
from django.http import Http404
from django.urls import reverse
import os, json
from .models import Material, MarcaMaterial, TipoMaterial, Herramienta, MarcaHerramienta, TipoHerramienta, EstadoHerramienta, CategoriaHerramienta, Bodega, TipoBodega, Bodeguero, Trabajador, Obrero, Cargo
from django.db import models as dj_models



def admin_view(request):
	return render(request, 'templatesapp/admin.html')

# helpers para convertir instancia a dict para la plantilla
def _material_to_dict(mat):
	return {
		'id': getattr(mat, 'id_material'),
		'name': getattr(mat, 'nombre_material'),
		'price': float(getattr(mat, 'precio') or 0),
		'description': getattr(mat, 'descripcion_material'),
		'brand': getattr(mat.id_marca, 'nombre_marca') if getattr(mat, 'id_marca', None) else '',
		'material_type': getattr(mat.id_tipo_material, 'nombre_tipo_material') if getattr(mat, 'id_tipo_material', None) else '',
		'stock_minimo': getattr(mat, 'stock_minimo', None),
		'stock_disponible': getattr(mat, 'stock_disponible', None),
		'dimensiones': getattr(mat, 'dimensiones', ''),
		'expiry_date': getattr(mat, 'fecha_vencimiento', '') if getattr(mat, 'fecha_vencimiento', None) else ''
	}

# helper para herramienta
def _herramienta_to_dict(h):
	return {
		'id': getattr(h, 'id_herramienta'),
		'name': getattr(h, 'nombre_herramienta'),
		'estado': getattr(h.id_estado, 'id_estado') if getattr(h, 'id_estado', None) else '',
		'categoria': getattr(h.id_categoria, 'id_categoria') if getattr(h, 'id_categoria', None) else '',
		'tool_type': getattr(h.id_tipo_herramienta, 'id_tipo_herramienta') if getattr(h, 'id_tipo_herramienta', None) else '',
		'brand': getattr(h.id_marca, 'id_marca') if getattr(h, 'id_marca', None) else '',
		'price': float(getattr(h, 'precio') or 0),
		'dimensions': getattr(h, 'dimensiones') or '',
		'description': getattr(h, 'descripcion_herramienta'),
		'stock_total': getattr(h, 'stock_total', 0)
	}

def materials_view(request):
	"""
	Lista y búsqueda desde DB. Soporta ?q=texto y ?edit=<id>.
	"""
	q = request.GET.get('q', '').strip()
	edit_id = request.GET.get('edit')
	items_qs = Material.objects.select_related('id_marca', 'id_tipo_material').all()
	if q:
		items_qs = items_qs.filter(
			# búsquedas sobre los campos relevantes
			dj_models.Q(nombre_material__icontains=q) |
			dj_models.Q(descripcion_material__icontains=q) |
			dj_models.Q(id_marca__nombre_marca__icontains=q) |
			dj_models.Q(id_tipo_material__nombre_tipo_material__icontains=q)
		)
	items = [_material_to_dict(m) for m in items_qs]
	edit_item = None
	if edit_id:
		try:
			eid = int(edit_id)
			mat = Material.objects.select_related('id_marca','id_tipo_material').filter(id_material=eid).first()
			if mat:
				edit_item = _material_to_dict(mat)
		except:
			edit_item = None
	return render(request, 'templatesapp/materials.html', {'materials': items, 'q': q, 'edit_item': edit_item})

def materials_add(request):
	"""
	Crear material en DB. Crea marca/tipo si no existen.
	"""
	if request.method == 'POST':
		name = request.POST.get('name', '').strip()
		price = request.POST.get('price', '').strip()
		description = request.POST.get('description', '').strip()
		brand = request.POST.get('brand', '').strip()
		material_type = request.POST.get('material_type', '').strip()

		stock_minimo = request.POST.get('stock_minimo', '').strip()
		stock_disponible = request.POST.get('stock_disponible', '').strip()
		dimensiones = request.POST.get('dimensiones', '').strip()
		fecha_vencimiento = request.POST.get('fecha_vencimiento', '').strip()

		# obtener/crear marca y tipo
		marca_obj, _ = MarcaMaterial.objects.get_or_create(nombre_marca=brand or 'Sin marca')
		tipo_obj, _ = TipoMaterial.objects.get_or_create(nombre_tipo_material=material_type or 'General')
		try:
			price_val = float(price) if price != '' else 0
		except:
			price_val = 0
		try:
			stock_min = int(stock_minimo) if stock_minimo != '' else None
		except:
			stock_min = None
		try:
			stock_disp = int(stock_disponible) if stock_disponible != '' else None
		except:
			stock_disp = None

		Material.objects.create(
			id_marca=marca_obj,
			id_tipo_material=tipo_obj,
			nombre_material=name,
			descripcion_material=description,
			precio=price_val,
			stock_minimo=stock_min,
			stock_disponible=stock_disp if stock_disp is not None else 0,
			dimensiones=dimensiones or '',
			fecha_vencimiento=fecha_vencimiento or None
		)
	return redirect('materials')

def materials_edit(request, mid):
	"""
	Actualizar material en DB.
	"""
	mid = int(mid)
	mat = Material.objects.select_related('id_marca','id_tipo_material').filter(id_material=mid).first()
	if not mat:
		raise Http404("Material no encontrado")
	if request.method == 'POST':
		mat.nombre_material = request.POST.get('name', '').strip()
		price = request.POST.get('price', '').strip()
		try:
			mat.precio = float(price) if price != '' else 0
		except:
			mat.precio = 0
		mat.descripcion_material = request.POST.get('description', '').strip()

		brand = request.POST.get('brand', '').strip()
		material_type = request.POST.get('material_type', '').strip()
		if brand:
			marca_obj, _ = MarcaMaterial.objects.get_or_create(nombre_marca=brand)
			mat.id_marca = marca_obj
		if material_type:
			tipo_obj, _ = TipoMaterial.objects.get_or_create(nombre_tipo_material=material_type)
			mat.id_tipo_material = tipo_obj

		stock_minimo = request.POST.get('stock_minimo', '').strip()
		stock_disponible = request.POST.get('stock_disponible', '').strip()
		dimensiones = request.POST.get('dimensiones', '').strip()
		fecha_vencimiento = request.POST.get('fecha_vencimiento', '').strip()
		try:
			mat.stock_minimo = int(stock_minimo) if stock_minimo != '' else None
		except:
			mat.stock_minimo = None
		try:
			mat.stock_disponible = int(stock_disponible) if stock_disponible != '' else 0
		except:
			mat.stock_disponible = 0
		mat.dimensiones = dimensiones or ''
		mat.fecha_vencimiento = fecha_vencimiento or None

		mat.save()
		return redirect('materials')
	# GET -> redirige a la lista con ?edit=mid
	return redirect(f"{reverse('materials')}?edit={mid}")

def materials_delete(request, mid):
	"""
	Eliminar material de DB.
	"""
	if request.method == 'POST':
		Material.objects.filter(id_material=int(mid)).delete()
	return redirect('materials')

# Nuevas utilidades y vistas para herramientas (JSON en <BASE_DIR>/data/herramientas.json)
def herramientas_view(request):
	"""
	Lista y búsqueda de herramientas desde DB. Soporta ?q=texto y ?edit=<id>.
	"""
	q = request.GET.get('q', '').strip()
	edit_id = request.GET.get('edit')
	items_qs = Herramienta.objects.select_related('id_marca', 'id_tipo_herramienta', 'id_estado', 'id_categoria').all()
	if q:
		items_qs = items_qs.filter(
			dj_models.Q(nombre_herramienta__icontains=q) |
			dj_models.Q(descripcion_herramienta__icontains=q) |
			dj_models.Q(id_marca__nombre_marca__icontains=q) |
			dj_models.Q(id_tipo_herramienta__nombre_tipo_herramienta__icontains=q)
		)
	items = [_herramienta_to_dict(h) for h in items_qs]
	edit_item = None
	if edit_id:
		try:
			eid = int(edit_id)
			h = Herramienta.objects.select_related('id_marca','id_tipo_herramienta','id_estado','id_categoria').filter(id_herramienta=eid).first()
			if h:
				edit_item = _herramienta_to_dict(h)
		except:
			edit_item = None

	# Obtener todas las opciones para los selects
	context = {
		'items': items,
		'q': q,
		'edit_item': edit_item,
		'resource_title': 'Herramientas',
		'list_url': 'herramientas',
		'add_url': 'herramientas_add',
		'edit_url': 'herramientas_edit',
		'delete_url': 'herramientas_delete',
		# Añadir opciones para los selects
		'estados': EstadoHerramienta.objects.all(),
		'categorias': CategoriaHerramienta.objects.all(),
		'tipos': TipoHerramienta.objects.all(),
		'marcas': MarcaHerramienta.objects.all(),
	}
	return render(request, 'templatesapp/resource.html', context)

def herramientas_add(request):
	"""
	Crear herramienta en DB usando los IDs de los selects.
	"""
	if request.method == 'POST':
		try:
			# Obtener los objetos relacionados usando los IDs de los selects
			estado = EstadoHerramienta.objects.get(id_estado=request.POST.get('estado'))
			categoria = CategoriaHerramienta.objects.get(id_categoria=request.POST.get('categoria'))
			tipo = TipoHerramienta.objects.get(id_tipo_herramienta=request.POST.get('tool_type'))
			marca = MarcaHerramienta.objects.get(id_marca=request.POST.get('brand'))
			
			# Procesar valores numéricos
			try:
				price_val = float(request.POST.get('price', '0'))
			except:
				price_val = 0
			try:
				stock_val = int(request.POST.get('stock_total', '0'))
			except:
				stock_val = 0

			# Crear la herramienta con todas sus relaciones
			Herramienta.objects.create(
				nombre_herramienta=request.POST.get('name', '').strip(),
				id_estado=estado,
				id_categoria=categoria,
				id_tipo_herramienta=tipo,
				id_marca=marca,
				precio=price_val,
				dimensiones=request.POST.get('dimensions', ''),
				descripcion_herramienta=request.POST.get('description', ''),
				stock_total=stock_val
			)
		except (EstadoHerramienta.DoesNotExist, CategoriaHerramienta.DoesNotExist,
				TipoHerramienta.DoesNotExist, MarcaHerramienta.DoesNotExist) as e:
			# Manejar el caso de IDs inválidos
			print(f"Error al crear herramienta: {e}")
	return redirect('herramientas')

def herramientas_edit(request, mid):
	"""
	Actualizar herramienta en DB usando los IDs de los selects.
	"""
	mid = int(mid)
	h = Herramienta.objects.select_related('id_marca','id_tipo_herramienta','id_estado','id_categoria').filter(id_herramienta=mid).first()
	if not h:
		raise Http404("Herramienta no encontrada")
	if request.method == 'POST':
		try:
			# Actualizar relaciones usando los IDs de los selects
			h.id_estado = EstadoHerramienta.objects.get(id_estado=request.POST.get('estado'))
			h.id_categoria = CategoriaHerramienta.objects.get(id_categoria=request.POST.get('categoria'))
			h.id_tipo_herramienta = TipoHerramienta.objects.get(id_tipo_herramienta=request.POST.get('tool_type'))
			h.id_marca = MarcaHerramienta.objects.get(id_marca=request.POST.get('brand'))
			
			# Actualizar campos simples
			h.nombre_herramienta = request.POST.get('name', '').strip()
			try:
				h.precio = float(request.POST.get('price', '0'))
			except:
				h.precio = 0
			h.dimensiones = request.POST.get('dimensions', '')
			h.descripcion_herramienta = request.POST.get('description', '')
			try:
				h.stock_total = int(request.POST.get('stock_total', '0'))
			except:
				h.stock_total = 0
				
			h.save()
		except (EstadoHerramienta.DoesNotExist, CategoriaHerramienta.DoesNotExist,
				TipoHerramienta.DoesNotExist, MarcaHerramienta.DoesNotExist) as e:
			print(f"Error al actualizar herramienta: {e}")
		return redirect('herramientas')
	return redirect(f"{reverse('herramientas')}?edit={mid}")

def herramientas_delete(request, mid):
	"""
	Eliminar herramienta de DB.
	"""
	if request.method == 'POST':
		Herramienta.objects.filter(id_herramienta=int(mid)).delete()
	return redirect('herramientas')

def _bodega_file_path():
	data_dir = os.path.join(settings.BASE_DIR, 'data')
	os.makedirs(data_dir, exist_ok=True)
	return os.path.join(data_dir, 'bodegas.json')

def _load_bodegas():
	fn = _bodega_file_path()
	if not os.path.exists(fn):
		with open(fn, 'w', encoding='utf-8') as f:
			json.dump([], f, ensure_ascii=False, indent=2)
	with open(fn, 'r', encoding='utf-8') as f:
		try:
			return json.load(f)
		except json.JSONDecodeError:
			return []

def _save_bodegas(items):
	fn = _bodega_file_path()
	with open(fn, 'w', encoding='utf-8') as f:
		json.dump(items, f, ensure_ascii=False, indent=2)

def _bodega_to_dict(b):
	return {
		'id': getattr(b, 'id_bodega'),
		'name': getattr(b, 'nombre_bodega'),
		'address': getattr(b, 'direccion'),
		'capacity': getattr(b, 'capacidad'),
		'warehouse_type': getattr(b.id_tipo_bodega, 'nombre_tipo_bodega') if getattr(b, 'id_tipo_bodega', None) else '',
		'warehouse_type_id': getattr(b.id_tipo_bodega, 'id_tipo_bodega') if getattr(b, 'id_tipo_bodega', None) else ''
	}

def bodegas_view(request):
	"""
	Lista y búsqueda de bodegas (desde DB). Soporta ?q=texto y ?edit=<id>.
	"""
	q = request.GET.get('q', '').strip()
	edit_id = request.GET.get('edit')
	items_qs = Bodega.objects.select_related('id_tipo_bodega').all()
	if q:
		items_qs = items_qs.filter(
			dj_models.Q(nombre_bodega__icontains=q) |
			dj_models.Q(direccion__icontains=q) |
			dj_models.Q(id_tipo_bodega__nombre_tipo_bodega__icontains=q)
		)
	items = [_bodega_to_dict(b) for b in items_qs]
	edit_item = None
	if edit_id:
		try:
			eid = int(edit_id)
			b = Bodega.objects.select_related('id_tipo_bodega').filter(id_bodega=eid).first()
			if b:
				edit_item = _bodega_to_dict(b)
		except:
			edit_item = None
	# opciones para select de tipo de bodega
	tipo_bodegas = TipoBodega.objects.all()
	context = {
		'items': items,
		'q': q,
		'edit_item': edit_item,
		'tipo_bodegas': tipo_bodegas,
	}
	return render(request, 'templatesapp/bodegas.html', context)

def bodegas_add(request):
	"""
	Crear bodega en DB. Se recibe id de tipo de bodega desde select.
	"""
	if request.method == 'POST':
		name = request.POST.get('name', '').strip()
		address = request.POST.get('address', '').strip()
		capacity = request.POST.get('capacity', '').strip()
		warehouse_type_id = request.POST.get('warehouse_type', '').strip()
		try:
			cap_val = float(capacity) if capacity != '' else 0
		except:
			cap_val = 0
		tipo_obj = None
		if warehouse_type_id:
			try:
				tipo_obj = TipoBodega.objects.get(id_tipo_bodega=int(warehouse_type_id))
			except TipoBodega.DoesNotExist:
				tipo_obj = None
		Bodega.objects.create(
			id_tipo_bodega=tipo_obj,
			nombre_bodega=name or None,
			capacidad=cap_val,
			direccion=address or ''
		)
	return redirect('bodegas')

def bodegas_edit(request, mid):
	"""
	Actualizar bodega en DB.
	"""
	mid = int(mid)
	b = Bodega.objects.select_related('id_tipo_bodega').filter(id_bodega=mid).first()
	if not b:
		raise Http404("Bodega no encontrada")
	if request.method == 'POST':
		b.nombre_bodega = request.POST.get('name', '').strip() or None
		b.direccion = request.POST.get('address', '').strip()
		capacity = request.POST.get('capacity', '').strip()
		try:
			b.capacidad = float(capacity) if capacity != '' else 0
		except:
			b.capacidad = 0
		warehouse_type_id = request.POST.get('warehouse_type', '').strip()
		if warehouse_type_id:
			try:
				b.id_tipo_bodega = TipoBodega.objects.get(id_tipo_bodega=int(warehouse_type_id))
			except TipoBodega.DoesNotExist:
				b.id_tipo_bodega = None
		else:
			b.id_tipo_bodega = None
		b.save()
		return redirect('bodegas')
	# GET -> redirige a la página de lista con ?edit=mid
	return redirect(f"{reverse('bodegas')}?edit={mid}")

def bodegas_delete(request, mid):
	"""
	Eliminar bodega de DB.
	"""
	if request.method == 'POST':
		Bodega.objects.filter(id_bodega=int(mid)).delete()
	return redirect('bodegas')

def _bodeguero_file_path():
	data_dir = os.path.join(settings.BASE_DIR, 'data')
	os.makedirs(data_dir, exist_ok=True)
	return os.path.join(data_dir, 'bodegueros.json')

def _load_bodegueros():
	fn = _bodeguero_file_path()
	if not os.path.exists(fn):
		with open(fn, 'w', encoding='utf-8') as f:
			json.dump([], f, ensure_ascii=False, indent=2)
	with open(fn, 'r', encoding='utf-8') as f:
		try:
			return json.load(f)
		except json.JSONDecodeError:
			return []

def _save_bodegueros(items):
	fn = _bodeguero_file_path()
	with open(fn, 'w', encoding='utf-8') as f:
		json.dump(items, f, ensure_ascii=False, indent=2)

def _bodeguero_to_dict(b):
	return {
		'id': getattr(b, 'id_bodeguero'),
		'nombre': getattr(b.id_trabajador, 'nombre') if getattr(b, 'id_trabajador', None) else '',
		'rut': getattr(b.id_trabajador, 'rut') if getattr(b, 'id_trabajador', None) else '',
		'email': getattr(b.id_trabajador, 'email') if getattr(b, 'id_trabajador', None) else '',
		'telefono': getattr(b.id_trabajador, 'telefono') if getattr(b, 'id_trabajador', None) else '',
		'sueldo': getattr(b.id_trabajador, 'sueldo') if getattr(b, 'id_trabajador', None) else '',
		'fecha_contratacion': getattr(b.id_trabajador, 'fecha_contratacion') if getattr(b, 'id_trabajador', None) else '',
		'bodega': getattr(b.id_bodega, 'nombre_bodega') if getattr(b, 'id_bodega', None) else '',
		'bodega_id': getattr(b.id_bodega, 'id_bodega') if getattr(b, 'id_bodega', None) else '',
		'contrasena': getattr(b.id_trabajador, 'contrasena') if getattr(b, 'id_trabajador', None) else ''
	}

def bodegueros_view(request):
	"""
	Lista y búsqueda de bodegueros desde DB. Soporta ?q=texto y ?edit=<id>.
	"""
	q = request.GET.get('q', '').strip()
	edit_id = request.GET.get('edit')
	items_qs = Bodeguero.objects.select_related('id_trabajador', 'id_bodega').all()
	if q:
		items_qs = items_qs.filter(
			# corregido: usar el campo 'nombre' del Trabajador
			dj_models.Q(id_trabajador__nombre__icontains=q) |
			dj_models.Q(id_trabajador__rut__icontains=q) |
			dj_models.Q(id_bodega__nombre_bodega__icontains=q)
		)
	items = [_bodeguero_to_dict(b) for b in items_qs]
	edit_item = None
	if edit_id:
		try:
			eid = int(edit_id)
			b = Bodeguero.objects.select_related('id_trabajador','id_bodega').filter(id_bodeguero=eid).first()
			if b:
				edit_item = _bodeguero_to_dict(b)
		except:
			edit_item = None
	# pasar bodegas para el select en el formulario
	bodegas = Bodega.objects.all()
	context = {
		'items': items,
		'q': q,
		'edit_item': edit_item,
		'bodegas': bodegas,
	}
	return render(request, 'templatesapp/bodegueros.html', context)

def bodegueros_add(request):
	"""
	Crear bodeguero y trabajador asociado en DB.
	"""
	if request.method == 'POST':
		# aceptar varios nombres de campo por compatibilidad con templates
		nombre = request.POST.get('nombre_completo', '').strip() or request.POST.get('nombre', '').strip() or request.POST.get('first_name', '').strip()
		rut = request.POST.get('rut', '').strip()
		email = request.POST.get('email', '').strip()
		telefono = request.POST.get('telefono', '').strip()
		sueldo = request.POST.get('sueldo', '').strip()
		fecha_contratacion = request.POST.get('fecha_contratacion', '').strip()
		bodega_id = request.POST.get('bodega', '').strip()

		try:
			sueldo_val = float(sueldo) if sueldo != '' else None
		except:
			sueldo_val = None

		# crear Trabajador
		trab = Trabajador.objects.create(
			nombre=nombre or '',
			rut=rut or '',
			email=email or None,
			telefono=telefono or '',
			sueldo=int(sueldo_val) if sueldo_val is not None else None,
			fecha_contratacion=fecha_contratacion or None,
			contrasena=request.POST.get('contrasena', '').strip() or None
		)
		# asociar Bodega si existe
		bodega_obj = None
		if bodega_id:
			try:
				bodega_obj = Bodega.objects.get(id_bodega=int(bodega_id))
			except Bodega.DoesNotExist:
				bodega_obj = None
		# crear Bodeguero
		Bodeguero.objects.create(
			id_trabajador=trab,
			id_bodega=bodega_obj
		)
	return redirect('bodegueros')

def bodegueros_edit(request, mid):
	"""
	Actualizar bodeguero y su trabajador.
	"""
	mid = int(mid)
	b = Bodeguero.objects.select_related('id_trabajador','id_bodega').filter(id_bodeguero=mid).first()
	if not b:
		raise Http404("Bodeguero no encontrado")
	if request.method == 'POST':
		# aceptar varios nombres de campo por compatibilidad
		nombre = request.POST.get('nombre_completo', '').strip() or request.POST.get('nombre', '').strip() or request.POST.get('first_name', '').strip()
		# actualizar trabajador
		trab = b.id_trabajador
		trab.nombre = nombre
		trab.rut = request.POST.get('rut', '').strip()
		trab.email = request.POST.get('email', '').strip() or None
		trab.telefono = request.POST.get('telefono', '').strip()
		sueldo = request.POST.get('sueldo', '').strip()
		try:
			trab.sueldo = int(sueldo) if sueldo != '' else None
		except:
			trab.sueldo = None
		trab.fecha_contratacion = request.POST.get('fecha_contratacion', '').strip() or None
		trab.contrasena = request.POST.get('contrasena', '').strip() or None
		trab.save()

		# actualizar bodega asignada
		bodega_id = request.POST.get('bodega', '').strip()
		if bodega_id:
			try:
				b.id_bodega = Bodega.objects.get(id_bodega=int(bodega_id))
			except Bodega.DoesNotExist:
				b.id_bodega = None
		else:
			b.id_bodega = None
		b.save()
		return redirect('bodegueros')
	# GET -> redirige a la lista de bodegueros with ?edit=mid
	return redirect(f"{reverse('bodegueros')}?edit={mid}")

def bodegueros_delete(request, mid):
	"""
	Eliminar bodeguero (y opcionalmente el trabajador).
	"""
	if request.method == 'POST':
		b = Bodeguero.objects.filter(id_bodeguero=int(mid)).first()
		if b:
			# opcional: eliminar también trabajador relacionado
			trab = b.id_trabajador
			b.delete()
			# eliminar trabajador si no usado en otras tablas (riesgo: chequear dependencias)
			try:
				trab.delete()
			except:
				pass
	return redirect('bodegueros')

def _supervisor_file_path():
	data_dir = os.path.join(settings.BASE_DIR, 'data')
	os.makedirs(data_dir, exist_ok=True)
	return os.path.join(data_dir, 'supervisores.json')

def _load_supervisores():
	fn = _supervisor_file_path()
	if not os.path.exists(fn):
		with open(fn, 'w', encoding='utf-8') as f:
			json.dump([], f, ensure_ascii=False, indent=2)
	with open(fn, 'r', encoding='utf-8') as f:
		try:
			return json.load(f)
		except json.JSONDecodeError:
			return []

def _save_supervisores(items):
	fn = _supervisor_file_path()
	with open(fn, 'w', encoding='utf-8') as f:
		json.dump(items, f, ensure_ascii=False, indent=2)

def supervisores_view(request):
	"""
	Lista y búsqueda de supervisores. Si se pasa ?edit=<id> devuelve edit_item.
	"""
	q = request.GET.get('q', '').strip()
	edit_id = request.GET.get('edit')
	items = _load_supervisores()
	if q:
		q_lower = q.lower()
		items = [
			m for m in items if
			q_lower in str(m.get('name','')).lower() or
			q_lower in str(m.get('project_code','')).lower()
		]
	edit_item = None
	if edit_id:
		try:
			eid = int(edit_id)
			edit_item = next((m for m in _load_supervisores() if m.get('id') == eid), None)
		except:
			edit_item = None
	context = {
		'items': items,
		'q': q,
		'edit_item': edit_item,
	}
	return render(request, 'templatesapp/supervisores.html', context)

def supervisores_add(request):
	"""
	POST: añadir supervisor.
	"""
	if request.method == 'POST':
		name = request.POST.get('name', '').strip()
		salary = request.POST.get('salary', '').strip()
		project_code = request.POST.get('project_code', '').strip()
		items = _load_supervisores()
		next_id = max([m.get('id', 0) for m in items], default=0) + 1
		try:
			salary_val = float(salary) if salary != '' else 0
		except:
			salary_val = 0
		items.append({
			'id': next_id,
			'name': name,
			'salary': salary_val,
			'project_code': project_code
		})
		_save_supervisores(items)
	return redirect('supervisores')

def supervisores_edit(request, mid):
	"""
	POST: actualizar supervisor. GET redirige a ?edit=<mid>.
	"""
	mid = int(mid)
	items = _load_supervisores()
	item = next((m for m in items if m.get('id') == mid), None)
	if not item:
		raise Http404("Supervisor no encontrado")
	if request.method == 'POST':
		item['name'] = request.POST.get('name', '').strip()
		salary = request.POST.get('salary', '').strip()
		try:
			item['salary'] = float(salary) if salary != '' else 0
		except:
			item['salary'] = 0
		item['project_code'] = request.POST.get('project_code', '').strip()
		_save_supervisores(items)
		return redirect('supervisores')
	# GET -> redirige a la página de lista con ?edit=mid
	return redirect(f"{reverse('supervisores')}?edit={mid}")

def supervisores_delete(request, mid):
	"""
	POST: elimina supervisor.
	"""
	if request.method == 'POST':
		items = _load_supervisores()
		items = [m for m in items if m.get('id') != int(mid)]
		_save_supervisores(items)
	return redirect('supervisores')

def _obrero_file_path():
	data_dir = os.path.join(settings.BASE_DIR, 'data')
	os.makedirs(data_dir, exist_ok=True)
	return os.path.join(data_dir, 'obreros.json')

def _load_obreros():
	fn = _obrero_file_path()
	if not os.path.exists(fn):
		with open(fn, 'w', encoding='utf-8') as f:
			json.dump([], f, ensure_ascii=False, indent=2)
	with open(fn, 'r', encoding='utf-8') as f:
		try:
			return json.load(f)
		except json.JSONDecodeError:
			return []

def _save_obreros(items):
	fn = _obrero_file_path()
	with open(fn, 'w', encoding='utf-8') as f:
		json.dump(items, f, ensure_ascii=False, indent=2)

def _obrero_to_dict(o):
    return {
        'id': getattr(o, 'id_obrero'),
        'nombre_completo': getattr(o.id_trabajador, 'nombre', ''),
        'rut': getattr(o.id_trabajador, 'rut', ''),
        'telefono': getattr(o.id_trabajador, 'telefono', ''),
        'fecha_contratacion': getattr(o.id_trabajador, 'fecha_contratacion', ''),
        'salary': getattr(o.id_trabajador, 'sueldo', 0),
        'position': getattr(o.id_cargo, 'nombre_cargo', '') if getattr(o, 'id_cargo', None) else '',
        'cargo_id': getattr(o.id_cargo, 'id_cargo', '') if getattr(o, 'id_cargo', None) else ''
    }

def obreros_view(request):
	"""
	Lista y búsqueda de obreros. Si se pasa ?edit=<id> devuelve edit_item para precargar edición.
	"""
	q = request.GET.get('q', '').strip()
	edit_id = request.GET.get('edit')
	items_qs = Obrero.objects.select_related('id_trabajador', 'id_cargo').all()
	if q:
		items_qs = items_qs.filter(
			dj_models.Q(id_trabajador__nombre__icontains=q) |
			dj_models.Q(id_trabajador__rut__icontains=q) |
			dj_models.Q(id_cargo__nombre_cargo__icontains=q)
		)
	items = [_obrero_to_dict(o) for o in items_qs]
	edit_item = None
	if edit_id:
		try:
			eid = int(edit_id)
			o = Obrero.objects.select_related('id_trabajador', 'id_cargo').filter(id_obrero=eid).first()
			if o:
				edit_item = _obrero_to_dict(o)
		except:
			edit_item = None

	# Obtener todos los cargos para el select
	cargos = Cargo.objects.all()
	context = {
		'items': items,
		'q': q,
		'edit_item': edit_item,
		'cargos': cargos
	}
	return render(request, 'templatesapp/obreros.html', context)

def obreros_add(request):
	"""
	POST: añadir obrero.
	"""
	if request.method == 'POST':
		nombre_completo = request.POST.get('nombre_completo', '').strip()
		rut = request.POST.get('rut', '').strip()
		telefono = request.POST.get('telefono', '').strip()
		fecha_contratacion = request.POST.get('fecha_contratacion', '').strip()
		salary = request.POST.get('salary', '').strip()
		cargo_id = request.POST.get('position', '').strip()

		try:
			salary_val = int(float(salary)) if salary != '' else None
		except:
			salary_val = None

		# Crear Trabajador
		trab = Trabajador.objects.create(
			nombre=nombre_completo,
			rut=rut,
			telefono=telefono,
			fecha_contratacion=fecha_contratacion or None,
			sueldo=salary_val
		)

		# Obtener cargo
		cargo = None
		if cargo_id:
			try:
				cargo = Cargo.objects.get(id_cargo=int(cargo_id))
			except Cargo.DoesNotExist:
				cargo = None

		# Crear Obrero
		Obrero.objects.create(
			id_trabajador=trab,
			id_cargo=cargo
		)
	return redirect('obreros')

def obreros_edit(request, mid):
	"""
	POST: actualizar obrero. GET redirige a ?edit=<mid>.
	"""
	mid = int(mid)
	o = Obrero.objects.select_related('id_trabajador','id_cargo').filter(id_obrero=mid).first()
	if not o:
		raise Http404("Obrero no encontrado")
	if request.method == 'POST':
		# aceptar varios nombres de campo por compatibilidad
		nombre = request.POST.get('nombre_completo', '').strip() or request.POST.get('nombre', '').strip()
		# actualizar trabajador
		ob = o.id_trabajador
		ob.nombre = nombre
		ob.rut = request.POST.get('rut', '').strip()
		ob.telefono = request.POST.get('telefono', '').strip()
		# usar el campo 'salary' que envía la plantilla
		salary = request.POST.get('salary', '').strip()
		try:
			ob.sueldo = int(salary) if salary != '' else None
		except:
			ob.sueldo = None
		ob.fecha_contratacion = request.POST.get('fecha_contratacion', '').strip() or None
		ob.save()

		# actualizar cargo usando el name="position" del select
		cargo_id = request.POST.get('position', '').strip()
		if cargo_id:
			try:
				o.id_cargo = Cargo.objects.get(id_cargo=int(cargo_id))
			except Cargo.DoesNotExist:
				o.id_cargo = None
		else:
			o.id_cargo = None
		o.save()
		return redirect('obreros')
	# GET -> redirige a la página de lista con ?edit=mid
	return redirect(f"{reverse('obreros')}?edit={mid}")

def obreros_delete(request, mid):
	if request.method == 'POST':
		o = Obrero.objects.filter(id_obrero=int(mid)).first()
		if o:
			# opcional: eliminar también trabajador relacionado
			trab = o.id_trabajador
			o.delete()
			# eliminar trabajador si no usado en otras tablas (riesgo: chequear dependencias)
			try:
				trab.delete()
			except:
				pass
	return redirect('obreros')

def login_view(request):
    if request.method == 'POST':
        username = request.POST.get('username', '').strip()
        password = request.POST.get('password', '')
        
        if username == 'admin@gmail.com' and password == 'admin':
            return redirect('dashboard')
        elif username == 'super@gmail.com' and password == 'super':
            return redirect('supervisor_dashboard')
        else:
            # Buscar bodeguero por email y contraseña
            try:
                trabajador = Trabajador.objects.get(email=username, contrasena=password)
                bodeguero = Bodeguero.objects.filter(id_trabajador=trabajador).first()
                if bodeguero:
                    return redirect('bodeguerolo')
            except Trabajador.DoesNotExist:
                pass
                
        return render(request, 'templatesapp/login.html', {'login_error': True, 'username': username})
    return render(request, 'templatesapp/login.html')

# Helpers para actividades y proyectos
def _load_resource(name):
    data_dir = os.path.join(settings.BASE_DIR, 'data')
    os.makedirs(data_dir, exist_ok=True)
    fn = os.path.join(data_dir, f'{name}.json')
    if not os.path.exists(fn):
        with open(fn, 'w', encoding='utf-8') as f:
            json.dump([], f, ensure_ascii=False, indent=2)
    with open(fn, 'r', encoding='utf-8') as f:
        try:
            return json.load(f)
        except json.JSONDecodeError:
            return []

def _save_resource(name, items):
    data_dir = os.path.join(settings.BASE_DIR, 'data')
    fn = os.path.join(data_dir, f'{name}.json')
    with open(fn, 'w', encoding='utf-8') as f:
        json.dump(items, f, ensure_ascii=False, indent=2)

# Vistas del supervisor
def supervisor_dashboard(request):
    actividades = _load_resource('actividades')
    proyectos = _load_resource('proyectos')
    context = {
        'actividades': actividades,
        'proyectos': proyectos,
        'q': request.GET.get('q', ''),
    }
    return render(request, 'templatesapp/super.html', context)

# CRUD Actividades
def actividad_add(request):
    if request.method == 'POST':
        items = _load_resource('actividades')
        next_id = max([m.get('id', 0) for m in items], default=0) + 1
        items.append({
            'id': next_id,
            'nombre': request.POST.get('nombre', '').strip(),
            'fecha_inicio': request.POST.get('fecha_inicio', ''),
            'fecha_termino': request.POST.get('fecha_termino', ''),
            'descripcion': request.POST.get('descripcion', '').strip()
        })
        _save_resource('actividades', items)
    return redirect('supervisor_dashboard')

def actividad_edit(request, aid):
    items = _load_resource('actividades')
    item = next((a for a in items if a.get('id') == aid), None)
    if not item:
        raise Http404("Actividad no encontrada")
    if request.method == 'POST':
        item.update({
            'nombre': request.POST.get('nombre', '').strip(),
            'fecha_inicio': request.POST.get('fecha_inicio', ''),
            'fecha_termino': request.POST.get('fecha_termino', ''),
            'descripcion': request.POST.get('descripcion', '').strip()
        })
        _save_resource('actividades', items)
        return redirect('supervisor_dashboard')
    return redirect(f"{reverse('supervisor_dashboard')}?edit_actividad={aid}")

def actividad_delete(request, aid):
    if request.method == 'POST':
        items = _load_resource('actividades')
        items = [a for a in items if a.get('id') != aid]
        _save_resource('actividades', items)
    return redirect('supervisor_dashboard')

# CRUD Proyectos
def proyecto_add(request):
    if request.method == 'POST':
        items = _load_resource('proyectos')
        next_id = max([p.get('id', 0) for p in items], default=0) + 1
        try:
            metros = float(request.POST.get('metros', '0'))
            presupuesto = float(request.POST.get('presupuesto', '0'))
            avance = float(request.POST.get('avance', '0'))
        except ValueError:
            metros = 0
            presupuesto = 0
            avance = 0
            
        items.append({
            'id': next_id,
            'nombre': request.POST.get('nombre', '').strip(),
            'metros': metros,
            'direccion': request.POST.get('direccion', '').strip(),
            'presupuesto': presupuesto,
            'avance': avance,
            'fecha_inicio': request.POST.get('fecha_inicio', ''),
            'fecha_termino_est': request.POST.get('fecha_termino_est', ''),
            'fecha_termino_real': request.POST.get('fecha_termino_real', ''),
            'estado': request.POST.get('estado', '').strip()
        })
        _save_resource('proyectos', items)
    return redirect('supervisor_dashboard')

def proyecto_edit(request, pid):
    items = _load_resource('proyectos')
    item = next((p for p in items if p.get('id') == pid), None)
    if not item:
        raise Http404("Obra no encontrada")
    if request.method == 'POST':
        try:
            metros = float(request.POST.get('metros', '0'))
            presupuesto = float(request.POST.get('presupuesto', '0'))
            avance = float(request.POST.get('avance', '0'))
        except ValueError:
            metros = 0
            presupuesto = 0
            avance = 0
            
        item.update({
            'nombre': request.POST.get('nombre', '').strip(),
            'metros': metros,
            'direccion': request.POST.get('direccion', '').strip(),
            'presupuesto': presupuesto,
            'avance': avance,
            'fecha_inicio': request.POST.get('fecha_inicio', ''),
            'fecha_termino_est': request.POST.get('fecha_termino_est', ''),
            'fecha_termino_real': request.POST.get('fecha_termino_real', ''),
            'estado': request.POST.get('estado', '').strip()
        })
        _save_resource('proyectos', items)
        return redirect('supervisor_dashboard')
    return redirect(f"{reverse('supervisor_dashboard')}?edit_proyecto={pid}")

def proyecto_delete(request, pid):
    if request.method == 'POST':
        items = _load_resource('proyectos')
        items = [p for p in items if p.get('id') != pid]
        _save_resource('proyectos', items)
    return redirect('supervisor_dashboard')

def bodeguero_lo_view(request):
    """
    Panel simplificado para bodegueros (BodegueroLo.html).
    """
    return render(request, 'templatesapp/BodegueroLo.html')